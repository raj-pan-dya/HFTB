﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to build a sample banking program to 
                          perform the common tasks like Withdraw and Deposit.
 * Version              : 1.0
 * Last Modified Date   : 28-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankLib;

namespace BankingApp
{
    class Program
    {

        static void Main(string[] args)
        {
            ICICI objIC1 = new ICICI();
            BankAccountTypeEnum value = BankAccountTypeEnum.Saving;
            objIC1.Deposit(50000, value);
            Console.Write("Balance in " + value +" Account of ICICI in IC1 after Deposit: ");
            Console.WriteLine(objIC1.GetBalance());

            ICICI objIC2 = new ICICI();
            value = BankAccountTypeEnum.Current;
            objIC2.Deposit(20000, value);
            Console.Write("Balance in " + value + " Account of ICICI in IC2 after Deposit: ");
            Console.WriteLine(objIC2.GetBalance());

            objIC1.Transfer(objIC2, 5000);
            Console.Write("Balance in ICICI in IC1 after Transfer: ");
            Console.WriteLine(objIC1.GetBalance());
            Console.Write("Balance in ICICI in IC2 after Transfer: ");
            Console.WriteLine(objIC2.GetBalance());




            HSBC objH1 = new HSBC();
            value = BankAccountTypeEnum.Saving;
            objH1.Deposit(50000, value);
            Console.Write("Balance in " + value + " Account of HSBC in H1 after Deposit: ");
            Console.WriteLine(objH1.GetBalance());

            HSBC objH2 = new HSBC();
            value = BankAccountTypeEnum.Current;
            objH2.Deposit(20000, value);
            Console.Write("Balance in " + value + " Account of HSBC in H1 after Deposit: ");
            Console.WriteLine(objH2.GetBalance());

            objH1.Transfer(objH2, 5000);
            Console.Write("Balance in HSBC in H1 after Transfer: ");
            Console.WriteLine(objH1.GetBalance());
            Console.Write("Balance in HSBC in H1 after Transfer: ");
            Console.WriteLine(objH2.GetBalance());

        }
    }
}
