﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to build a sample banking program to 
                          perform the common tasks like Withdraw and Deposit.
 * Version              : 1.0
 * Last Modified Date   : 28-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    //Enum type definition to specify possible set of values
    public enum BankAccountTypeEnum
    {
        Current = 1,
        Saving = 2
    }

    public interface IBankAccount
    {
        double GetBalance();
        void Deposit(double amount, BankAccountTypeEnum en);
        bool Withdraw(double amount);
        bool Transfer(IBankAccount toAccount, double amount);
        BankAccountTypeEnum AccountType { get; set; }
        double CalculateInterest(double amount);
    }
    
}
