﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to Read and Display the contents of a text file. 
                          Accept the name of the file from the user. Handle all the 
                          exceptions that might occur during reading.
 * Version              : 1.0
 * Last Modified Date   : 31-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab12_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Enter File name with complete path: ");
            string strFileName = Console.ReadLine();
            FileStream filestream1 = new FileStream(strFileName, FileMode.CreateNew, FileAccess.Write);
            StreamWriter streamWriter = new StreamWriter(filestream1);
            streamWriter.WriteLine("This is a Test");
            streamWriter.WriteLine("This is a Test");
            streamWriter.WriteLine("This is a Test");
            streamWriter.Flush();
            streamWriter.Close();
            filestream1.Close();

            FileStream fileStream2 = new FileStream(strFileName, FileMode.Open, FileAccess.Read);
            StreamReader streamReader = new StreamReader(fileStream2);
            int ch = streamReader.Read();
            while (ch > 0)
            {
                Console.Write((char)ch);
                ch = streamReader.Read();
            }
            streamReader.Read();
            streamReader.Close();
            fileStream2.Close();

            Console.ReadKey();
        }
    }
}
