﻿/*********************************************************************
 * File                 : Product.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to maintain a Contact List in a generic List Collection.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
    public class Product
    {

        private int _productNo;
        private string _productName;
        private int _rate;
        private int _stock;

        public int ProductNo
        {
            get
            {
                return _productNo;
            }
            set
            {
                _productNo = value;
            }
        }

        public string ProductName
        {
            get
            {
                return _productName;
            }
            set
            {
                _productName = value;
            }
        }

        public int Rate
        {
            get
            {
                return _rate;
            }
            set
            {
                _rate = value;
            }
        }

        public int Stock
        {
            get
            {
                return _stock;
            }
            set
            {
                _stock = value;
            }
        }

        public Product()
        {

        }
        public Product(int productNo, string productName, int rate, int stock)
        {
            ProductNo = productNo;
            ProductName = productName;
            Rate = rate;
            Stock = stock;
        }
    }
}
