﻿/*********************************************************************
 * File                 : ProductOps.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to maintain a Contact List in a generic List Collection.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ProductDetails
{
   public class ProductOps
    {
          //Product objProd = new Product();

        public ArrayList AddProduct(ArrayList a)
        {

            Product objProd = new Product();
            Console.WriteLine("Enter the Product Details.");

            Console.WriteLine("Enter the Product NO:");
            objProd.ProductNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Product Name:");
            objProd.ProductName = Console.ReadLine();

            Console.WriteLine("Enter the Product Rate:");
            objProd.Rate = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Product Stock:");
            objProd.Stock = Convert.ToInt32(Console.ReadLine());

            a.Add(objProd);
            return a;

        }

        public ArrayList SearchProduct(ArrayList b)
        {
            Console.WriteLine(" Product number you want to edit details of");
            int searchNumber = int.Parse(Console.ReadLine());

            for (int i = 0; i < b.Count; i++)
            {
                Product objProduct = b[i] as Product;

                if (objProduct.ProductNo == searchNumber)
                {
                    Console.WriteLine(objProduct.ProductNo + " " + objProduct.ProductName);
                }
                else
                {
                    Console.WriteLine(" Name not found");
                }
            }
            return b;
        }



    }
}
