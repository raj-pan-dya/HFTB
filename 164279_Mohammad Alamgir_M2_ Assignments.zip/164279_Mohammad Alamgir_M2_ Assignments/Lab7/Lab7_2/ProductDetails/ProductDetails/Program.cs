﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to maintain a Contact List in a generic List Collection.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
    class Program
    {
        
        static void Main(string[] args)
        {
            ArrayList prodList = new ArrayList();
            char choice;
            do
            {
                Console.WriteLine("============================");
                Console.WriteLine("1.Add Product");
                Console.WriteLine("2.Delete Currently Searched Product");
                Console.WriteLine("3.Search Product");
                Console.WriteLine("4.Save the Product");
                Console.WriteLine("============================");


                ProductOps objProdOps = new ProductOps();

                Console.WriteLine("Enter your choice:");
                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {

                    case 1:
                        objProdOps.AddProduct(prodList);
                        break;
                    case 2:
                        break;
                    case 3:
                        objProdOps.SearchProduct(prodList);
                        break;
                    case 4:
                        break;
                    default:
                        Console.WriteLine("Enter Correct Choice");
                        break;


              

            }
             Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit.");
            choice = Convert.ToChar(Console.ReadLine());
        } while (choice == 'y');


        }

        }
}
