﻿
/*********************************************************************
 * File                 : Employees.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to develop a Console based Client application
                          for the same requirement. The Client application should
                          allow Adding new Employee’s of specified type, Searching
                          Records, Delete Records and View all records operations.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Employee
{
    public class Employees
    {
         // Properties Creation

        public int EmployeeNo { get; set; }
        public string EmployeeName { get; set; }
        public int salary { get; set; }
        public int pf { get; set; }

        public Employees()
        {
            EmployeeNo = 0;
            EmployeeName = "";
            salary = 0;
            pf = 0;
        }

        // Parameterize Constructor

        public Employees(int num,string name,int sal,int pf)
        {
            EmployeeNo = num;
            EmployeeName = name;
            salary = sal;
            this.pf = pf;
        }
    }
}
