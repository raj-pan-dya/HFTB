﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to develop a Console based Client application
                          for the same requirement. The Client application should
                          allow Adding new Employee’s of specified type, Searching
                          Records, Delete Records and View all records operations.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employees> emp = new List<Employees>();
            char select;

            do
            {
                Console.WriteLine(" Select Option \n 1) ADD \n 2) Diplay ALL \n 3) Display Selected \n 4) Delete \n ");
                Console.Write(" Enter your Choice: ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                           // Add Employee
                        Console.Write(" Enter number of Employee: ");
                        int n = int.Parse(Console.ReadLine());

                        for (int index = 0; index < n; index++)
                        {
                            Employees objEmployees = new Employees();
                            Console.WriteLine(" Employee details");
                            Console.WriteLine();
                            Console.Write(" Enter the Employee No: ");
                            objEmployees.EmployeeNo = int.Parse(Console.ReadLine());
                            Console.Write(" Enter the Employee name: ");
                            objEmployees.EmployeeName = Console.ReadLine();
                            Console.Write(" Enter the Employee Salary: ");
                            objEmployees.salary = int.Parse(Console.ReadLine());
                            Console.Write(" Enter the Employee PF: ");
                            objEmployees.pf = int.Parse(Console.ReadLine());
                            Console.WriteLine();
                            emp.Add(objEmployees);

                        }
                        break;
                    case 2:
                        // Display Employee
                        Console.WriteLine(" Employee Details:-");
                        foreach (Employees c in emp)
                        {
                            Console.WriteLine("EmployeesNo={0}, EmployeesName={1}, salary={2}, pf={3}", c.EmployeeNo, c.EmployeeName, c.salary,c.pf);
                        }
                        break;
                    case 3:
                        // Display a particular Employee
                        Console.WriteLine(" Contact name you want to display:");
                        string searchName = Console.ReadLine();

                        for (int index = 0; index < emp.Count; index++)
                        {
                            if (emp[index].EmployeeName == searchName)
                            {
                                Console.WriteLine("ContactNo={0}, ContactName={1}, CellNo={2}, pf={3}", emp[index].EmployeeNo, emp[index].EmployeeName, emp[index].salary, emp[index].pf);
                            }
                            else
                            {
                                Console.WriteLine(" Name not found");

                            }
                        }
                        break;
                    case 4:
                        // Deleting the Contact

                        Console.WriteLine(" Contact name you want to delete details of");
                        string editName = Console.ReadLine();
                        for (int index = 0; index < emp.Count; index++)
                        {
                            if (emp[index].EmployeeName == editName)
                            {
                                emp.RemoveAt(index);
                            }
                            else
                            {
                                Console.WriteLine(" Name not found");
                            }




                        }
                        break;

                }
                Console.WriteLine("u want to continue");
                select = char.Parse(Console.ReadLine());

            } while (select != 'n');
        }
    }
}
