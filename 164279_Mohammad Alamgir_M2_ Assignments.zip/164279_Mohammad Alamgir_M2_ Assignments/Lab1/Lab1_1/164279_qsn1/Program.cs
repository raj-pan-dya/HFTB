﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to take input from user and display the same.
 * Version              : 1.0
 * Last Modified Date   : 23-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace _164279_qsn1
{
    class Program
    {

        static void Main(string[] args)
        {
            Employees[] emp = new Employees[2];

            // Take Employee Input Details

           Console.WriteLine("\nEnter Employee Details");
            Console.WriteLine("");
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("");
                emp[i] = new Employees();

                Console.Write("Employee ID : ");
                emp[i].empId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Employee Name : ");
                emp[i].empName = Console.ReadLine();

                Console.Write("Employee Address : ");
                emp[i].empAddress = Console.ReadLine();

                Console.Write("Employee City : ");
                emp[i].empCity = Console.ReadLine();

                Console.Write("Employee Department : ");
                emp[i].empDepartment = Console.ReadLine();

                Console.Write("Employee Salary : ");
                emp[i].empSalary =Convert.ToDouble(Console.ReadLine());

           }
            Console.WriteLine("");

            for (int i = 0; i < emp.Length; i++)
            {
                //To Print The Employee Details

                //emp[i].displayEmpDetails();

                // To print only Name and Salary
               
                Console.WriteLine((i+1)+"."+ "Employee Name: "+ emp[i].empName+"    "+ "Employee Salary: Rs"+ emp[i].empSalary);
               
            }

            Console.WriteLine("");

        }
    }
}
