﻿/*********************************************************************
 * File                 : Employee.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to maintain the employee records
 * Version              : 1.0
 * Last Modified Date   : 23-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employees
    {
        public int empId;
        public string empName, empAddress, empCity, empDepartment;
        public double empSalary;

        //Initialisation using Constructor
   
        public Employees()
        {
            this.empId = 0;
            this.empName = " ";
            this.empAddress = " ";
            this.empCity = " ";
            this.empDepartment = " ";
            this.empSalary = 0.0;
        }


        // Getting and Setting Of all the details of Employee by using properties

        public int Id
        {
            get {
                return empId;
            }

            set {
                empId = value;
            }
        }

        public string Name
        {
            get
            {
                return empName;
            }

            set
            {
                empName = value;
            }
        }

        public string Address
        {
            get
            {
                return empAddress;
            }

            set
            {
                empAddress = value;
            }
        }

        public string City
        {
            get
            {
                return empCity;
            }

            set
            {
                empCity = value;
            }
        }

        public string Department
        {
            get
            {
                return empDepartment;
            }

            set
            {
                empDepartment = value;
            }
        }

        public double Salary
        {
            get
            {
                return empSalary;
            }

            set
            {
                empSalary = value;
            }
        }

       // Display Fuction
 
        public void displayEmpDetails()
        {
            Console.WriteLine("Employee ID : " + this.empId + "Employee Name : " + this.empName + " Employee Address: " + this.empAddress + "Employee City" + this.empCity);
            Console.WriteLine("\n"+ "Employee Department" + this.empDepartment + "Employee Salary"+ this.empSalary);
        } 
    }
}
