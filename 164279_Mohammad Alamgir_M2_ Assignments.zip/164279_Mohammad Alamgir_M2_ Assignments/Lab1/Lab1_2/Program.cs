﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to take input from users and display the same.
 * Version              : 1.0
 * Last Modified Date   : 23-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn4
{
    class Program
    {
      // Main Fuction.
        static void Main(string[] args)
        {
            
            int rollNumber;
            string studentName, address;
            byte age;
            char gender;
            DateTime dob;
            float percentage;

            int n;
            Console.WriteLine("");
            Console.Write(" Enter the number of Students: ");
            n= Convert.ToInt32(Console.ReadLine());

            SchoolDemo[] student = new SchoolDemo[n];

            Console.WriteLine("");
            Console.WriteLine(" Enter the Student Details:");
            Console.WriteLine("");

            for (int i = 0; i < n; i++)
            {
                student[i] = new SchoolDemo();

                Console.Write(" Enter the Student Roll No: ");
                rollNumber = Convert.ToInt32(Console.ReadLine());

                Console.Write(" Enter the Student Name: ");
                studentName = Console.ReadLine();

                Console.Write(" Enter the Student Address: ");
                address = Console.ReadLine();

                Console.Write(" Enter the Student age: ");
                age = Convert.ToByte(Console.ReadLine());

                Console.Write(" Enter the Student gender: ");
                gender = Convert.ToChar(Console.ReadLine());

                Console.Write(" Enter the Student Date Of Birth: ");
                dob = Convert.ToDateTime(Console.ReadLine());

                Console.Write(" Enter the Student Percentage: ");
                percentage = float.Parse(Console.ReadLine());

                student[i].schoolDemo(rollNumber, studentName, address, age, gender, dob, percentage);

                Console.WriteLine("");
            }

            for (int i = 0; i < n; i++)
            {
                student[i].display();
            }

        }
    }
}
