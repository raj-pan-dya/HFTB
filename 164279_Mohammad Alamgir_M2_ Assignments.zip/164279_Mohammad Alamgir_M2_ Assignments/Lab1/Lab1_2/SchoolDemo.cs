﻿/*********************************************************************
 * File                 : SchoolDemo.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to maintain the student records.
 * Version              : 1.0
 * Last Modified Date   : 23-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn4
{
    class SchoolDemo
    {
        public int rollNumber;
        public string studentName, address;
        public byte age;
        public char gender;
        public DateTime dob;
        public float percentage;

        public void schoolDemo(int rollNumber, string studentName, string address, byte age, char gender, DateTime dob, float percentage)
        {
            this.rollNumber = rollNumber;
            this.studentName = studentName;
            this.address = address;
            this.age = age;
            this.gender = gender;
            this.dob = dob;
            this.percentage = percentage;
        }

        public void display()
        {
            Console.WriteLine("");
            Console.WriteLine("Student Roll No: " + rollNumber);
            Console.WriteLine("Student Name: " + studentName);
            Console.WriteLine("Student Address: " + address);
            Console.WriteLine("Student Age: " + age);
            Console.WriteLine("Student gender: " + gender);
            Console.WriteLine("Student DOB: " + dob);
            Console.WriteLine("Student Percentage: " + percentage);
            Console.WriteLine("");
            //+ "Student Name: " + studentName + "Student Address: " + address + "Student Age: " 
            //  + age + "Student gender: " + gender+ "Student Date Of Birth: " + dob + "Student percentage: " + percentage);
        }
    }
}
