﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to check the flow of Switch Case.
 * Version              : 1.0
 * Last Modified Date   : 24-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn3
{
    class Program
    {
        static void Main(string[] args)
        {
            char flag;
            do {

                Console.WriteLine("");
                Console.WriteLine(" ================== Swich Case Check Demo =====================");
                Console.WriteLine("");
                int num;
            Console.Write(" Enter any Integer: ");
            num = Convert.ToInt32(Console.ReadLine());

           // Switch Case

            switch (num)
            {

                case 1:
                        Console.WriteLine("");
                        Console.WriteLine(" You have entered 1");
                            break;

                case 2:
                        Console.WriteLine("");
                        Console.WriteLine(" You have entered 2");
                    break;

                case 3:
                        Console.WriteLine("");
                        Console.WriteLine(" You have entered 3");
                    break;


                case 4:
                        Console.WriteLine("");
                        Console.WriteLine(" You have entered 4");
                    break;


                case 5:
                        Console.WriteLine("");
                        Console.WriteLine(" You have entered 5");
                    break;


                default:
                    Console.WriteLine("");
                        if (num > 5)
                        {
                            Console.WriteLine(" Entered Integer is greater than range....!!!!");
                        }

                        else if (num < 1)
                        {
                            Console.WriteLine(" Entered Integer is less than range....!!!!");
                        }
                        break;

            }
            Console.WriteLine("");

            Console.WriteLine("Do you want to Continue?? Press y to Continue and n to exit.");
            flag = Convert.ToChar(Console.ReadLine());
        } while (flag == 'y');
        }
}
    }

