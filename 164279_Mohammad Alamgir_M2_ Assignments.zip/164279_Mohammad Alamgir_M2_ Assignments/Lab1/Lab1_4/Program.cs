﻿
/*********************************************************************
 * File                 : program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to design a calculator
 * Version              : 1.0
 * Last Modified Date   : 24-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.BackgroundColor="green";
            Console.WriteLine("------------------------ Calculator Application ----------------------------------");

            char flag;

            do
            {
                Console.WriteLine("");
                Console.WriteLine("=================== Menu ===================");
                Console.WriteLine("1. Addition");
                Console.WriteLine("2. Subtraction");
                Console.WriteLine("3. Multiplication");
                Console.WriteLine("4. Division");
                Console.WriteLine("5. Modulous");
                Console.WriteLine("============================================");

                Console.Write("Enter your Choice: ");

                //Console.WriteLine(" Press 1 for Addition, 2 for Subtraction, 3 for Multiplication and 4 for Division and 5 for Modulous");
                
                int operation;
                operation = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");
                int firstNo, secondNo;
                Console.Write("Enter the First number: ");
                firstNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the Second number: ");
                secondNo = Convert.ToInt32(Console.ReadLine());

                int result;

                Arithematic objCalculator = new Arithematic();

                switch (operation)
                {

                    case 1://Addition
                        Console.WriteLine("");
                        result = objCalculator.addition(firstNo, secondNo);
                        Console.WriteLine("The Addition of the numbers is: " + result);
                        break;

                    case 2://Subtraction
                        Console.WriteLine("");
                        result = objCalculator.subtraction(firstNo, secondNo);
                        Console.WriteLine("The Subtraction of the numbers is: " + result);
                        break;

                    case 3://Multiplication
                        Console.WriteLine("");
                        result = objCalculator.multiplication(firstNo, secondNo);
                        Console.WriteLine("The Multiplication of the numbers is: " + result);
                        break;

                    case 4://Division
                        Console.WriteLine("");
                        result = objCalculator.division(firstNo, secondNo);
                        Console.WriteLine("The Division of the numbers is: " + result);
                        break;

                   case 5://Modulous
                        Console.WriteLine("");
                        result = objCalculator.modulous(firstNo, secondNo);
                        Console.WriteLine("The Modulous of the numbers is: " + result);
                        break;

                    default:
                        Console.WriteLine("");
                        Console.WriteLine("Enter the valid Input");

                        break;

                }
                Console.WriteLine("");

                Console.WriteLine("Do you want to Continue?? Press y to Continue and n to exit.");
                flag = Convert.ToChar(Console.ReadLine());
            } while (flag == 'y');
        }

    }
}
