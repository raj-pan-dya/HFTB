﻿/*********************************************************************
 * File                 : Arithematic.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Class to define the functions of Calculator 
 * Version              : 1.0
 * Last Modified Date   : 24-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn2
{
    class Arithematic
    {

         //Add Function
        public int addition(int num1, int num2)
        {
            int result;
            result = num1 + num2;
            return result;
        }

          //Subtract Function
        public int subtraction(int num1, int num2)
        {
            int result;
            result = num1 - num2;
            return result;
        }

         // Multiplication Function
        public int multiplication(int num1, int num2)
        {
            int result;
            result = num1 * num2;
            return result;
        }

          //Division Function

        public int division(int num1, int num2)
        {
            int result;
            result = num1 / num2;
            return result;
        }
      
           //Modulous Function
        public int modulous(int num1, int num2)
        {
            int result;
            result = num1 % num2;
            return result;
        }

    }
}
