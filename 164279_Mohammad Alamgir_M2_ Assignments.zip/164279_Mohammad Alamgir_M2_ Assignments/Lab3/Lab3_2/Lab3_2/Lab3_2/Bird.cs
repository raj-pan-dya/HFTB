﻿
/*********************************************************************
 * File                 : Bird.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Class to perform function overloading .
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_2
{
     class Bird
    {
        
            public string Name;
            public double Maxheight;

           //Default Constructor
            public Bird() 
            {
                this.Name = "Mountain Eagle";
                this.Maxheight = 500;
               
            }

            //Overloaded Constructor

            public Bird(string birdname, double max_ht)
            {
                this.Name = "Another Bird";
                this.Maxheight = 0;
            }
 
            //Function to calculate fly condition

            public void fly()
            {
                Console.WriteLine(this.Name +"is flying at altitude"+ this.Maxheight);
            }

            //Function overloading

            public void fly(double AtHeight)
            {
            if (AtHeight <= this.Maxheight) {
                Console.WriteLine(this.Name + " flying at " + AtHeight.ToString());
            }
            else {

                Console.WriteLine(this.Name+" cannot fly at this height");
            }
            
        }
    }
}
