﻿/*********************************************************************
 * File                 : Supplier.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to to accept the details of the supplier 
                          from the user and invoke DisplayDetails method to 
                          display the given details of the supplier.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Supplier
    {
        int supplierId;
        string supplierName, city, phonenum, email;

        // Program to set details

        public void setDetails(int supplierId,string supplierName,string city,string phonenum, string email)
        {
            this.supplierId = supplierId;
            this.supplierName = supplierName;
            this.city = city;
            this.phonenum = phonenum;
            this.email = email;
        }

        // Program to display details

        public void displayDetails()
        {
            Console.WriteLine(supplierId + supplierName + city + phonenum + email);
        }
    }
}
