﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to to accept the details of the supplier 
                          from the user and invoke DisplayDetails method to 
                          display the given details of the supplier.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int supplierId;
            string supplierName, city, phonenum, email;

            Console.WriteLine("Enter Details");
            Console.WriteLine("Enter Id");
            supplierId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            supplierName = Console.ReadLine();
            Console.WriteLine("Enter city");
            city = Console.ReadLine();
            Console.WriteLine("Enter phonenum");
            phonenum = Console.ReadLine();
            Console.WriteLine("Enter email");
            email = Console.ReadLine();

            Supplier obj = new Supplier();
            obj.setDetails(supplierId,supplierName,city,phonenum,email);
            obj.displayDetails();
           
           





        }
    }
}
