﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to display the % of a particular Employee.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CorporateUniversity;

namespace _164279_qsn1
{
    class Program
    {
        static void Main(string[] args)
        {
            Participant objParticipant = new Participant();

            Console.WriteLine();
            Console.WriteLine(" Enter the Employee Details:- ");
            Console.WriteLine();

            Console.Write(" Enter the Employee ID: ");
            objParticipant.EmpId = Convert.ToInt32(Console.ReadLine());

            Console.Write(" Enter the Employee Name: ");
            objParticipant.Name = Console.ReadLine();

            Console.Write(" Enter the Employee foundation Marks: ");
            objParticipant.FoundationMarks= Convert.ToDouble(Console.ReadLine());

            Console.Write(" Enter the Employee WebBasic Marks: ");
            objParticipant.WebBasicMarks = Convert.ToDouble(Console.ReadLine());

            Console.Write(" Enter the Employee DotNet Marks: ");
            objParticipant.DotNetMarks = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine( "======================= " +Participant.CompanyName+ " ==========================");
            Console.WriteLine();

            objParticipant.calculateTotalMarks();
            Console.WriteLine();

            Console.WriteLine(" The Percentage obtained by Employee " + objParticipant.Name+" is " + objParticipant.calculatePercentage() + "%");

            Console.WriteLine();
        }
    }
}
