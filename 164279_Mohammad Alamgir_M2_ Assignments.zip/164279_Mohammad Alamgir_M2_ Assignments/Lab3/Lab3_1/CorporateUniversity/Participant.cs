﻿/*********************************************************************
 * File                 : Participant.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to display the % of a particular Employee.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateUniversity
{
    public class Participant
    {
        private int _empId;
        private string _name ;
        private static string _companyName;
        private double _foundationMarks, _webBasicMarks, _dotNetMarks;
        private double _obtainedMarks,_percentage;

        private double _totalMarks = 300; 

        // Properties Definition.
        public int EmpId
        {
            get {
                return _empId;
            }

            set {
                _empId = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public static string CompanyName
        {
            get
            {
                return _companyName;
            }

            set
            {
                _companyName = value;
            }
        }

        public double FoundationMarks
        {
            get
            {
                return _foundationMarks;
            }

            set
            {
                if(value < 0 || value > 100)
                {
                    _foundationMarks = 0;
                }
                else
                {
                    _foundationMarks = value;
                }
                
            }
        }

        public double WebBasicMarks
        {
            get
            {
                return _webBasicMarks;
            }

            set
            {
                if (value < 0 || value > 100)
                {
                    _webBasicMarks = 0;
                }
                else
                {
                    _webBasicMarks = value;
                }

            }
        }

        public double DotNetMarks
        {
            get
            {
                return _dotNetMarks;
            }

            set
            {
                if (value < 0 || value > 100)
                {
                    _dotNetMarks = 0;
                }
                else
                {
                    _dotNetMarks = value;
                }

            }
        }

        public double ObtainedMarks
        {
            get
            {
                return _obtainedMarks;
            }

            set
            {
                _obtainedMarks = value;
            }
        }

        public double Percentage
        {
            get
            {
                return _percentage;
            }

            set
            {
                _percentage = value;
            }
        }

        //Default Constructor

        public Participant()
        {

        }
       
        // Parameterized Constructor

        public Participant(int empId, string name, double foundationMarks, double webBasicMarks, double dotnetMarks)
        {
            EmpId = empId;
            Name = name;
            FoundationMarks = foundationMarks;
            WebBasicMarks = webBasicMarks;
            DotNetMarks = dotnetMarks;

        }
         
        // Static Constructor
 
        static Participant()
        {
            CompanyName = "Corporate University";
        }

         // Function to Calculate Total Marks

        public void calculateTotalMarks()
        {
            ObtainedMarks = FoundationMarks + WebBasicMarks + DotNetMarks;

            Console.WriteLine(" The total Obtained Marks is :"+ ObtainedMarks);
        }
        
         // Function to calculate the percentage

        public double calculatePercentage()
        {
            Percentage = (ObtainedMarks / _totalMarks) * 100;
           return Percentage;
        }

        //public double returnPercenatge()
        //{
        //    return Percentage;
        //}


    }
}
