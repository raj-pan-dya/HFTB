﻿
/*********************************************************************
 * File                 : Guests.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the Entitties of the project.
 * Version              : 1.0
 * Last Modified Date   : 01-Dec-2018
 * Change Description   : Description about the changes implemented
 ********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBook.Entities
{
    //Enum Definition of Relationship.

    public enum Relation 
    {
        FATHER=1,
        MOTHER=2,
        BROTHER=3,
        SISTER=4,
        COUSIN=5,
        UNCLE=6,
        AUNT=7,
        SON=8,
        DAUGHTER=9,
        FRIEND=10,
    }

    // Guest Entity Definition 

    public class Guest
    {
        private int guestID;

        // Defintion of Properties

        public int GuestID
        {
            get { return guestID; }
            set { guestID = value; }
        }
        private string guestName;

        public string GuestName
        {
            get { return guestName; }
            set { guestName = value; }
        }
        private string guestContactNumber;

        public string GuestContactNumber
        {
            get { return guestContactNumber; }
            set { guestContactNumber = value; }
        }

        private Relation guestRelationship;

        public Relation GuestRelationship
        {
            get { return guestRelationship; }
            set { guestRelationship = value; }
        }

       
        // Constructor to inintialise the memebers.

        public Guest()
        {
            guestID = 0;
            guestName = string.Empty;
            guestContactNumber = string.Empty;
        }
    }
}
