﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store cities in 1D Array.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn3
{
    class Program
    {
        static void Main(string[] args)
        {
           
            string[] city = new string[5];
            Console.WriteLine("");
            // Taking the maximum size from user.
           

            // Taking Input from User.

            Console.WriteLine("\nCities Entry:-");
            Console.WriteLine(" ");
            for (int i = 0; i < city.Length; i++)
            {
                Console.Write(" Enter the City{0}:  ",i);
                city[i] = Console.ReadLine();

            }

            Console.WriteLine("");
            //Displaying the list of Cities.
            Console.Write("The array Of Cities are:-  ( ");
            /*
            for (int i = 0; i < city.Length; i++)
            {
                if (i < 4)
                {
                    Console.Write( city[i] + ", ");
                }
                else if (i == 4)
                {
                    Console.Write(city[i]+" )");
                }

            }*/

            foreach (string strCity in city)
            {
                Console.Write(strCity+ " ");
            }


            Console.WriteLine(" )");
        }

        
    }
}
