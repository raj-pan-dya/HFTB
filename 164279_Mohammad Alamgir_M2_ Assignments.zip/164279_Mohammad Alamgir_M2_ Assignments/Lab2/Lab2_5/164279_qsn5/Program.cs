﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store book details in 2D Array.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn5
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            string[] columnNames = { "Book_Title", "Book_Author", "Book_Publisher", "Book_Price(Rs)" };
            // string[,] objbookDetails = new string[2, 4];

            BooksDemo objBookDemo = new BooksDemo();
            Console.WriteLine();
            Console.WriteLine("====================== Book Details Entry =======================");
            objBookDemo.getBookDetails();
            Console.WriteLine("======================= Book Details ============================");
            Console.WriteLine();
            for (i = 0; i < columnNames.Length; i++)
            {
                Console.Write(columnNames[i]+"\t");

            }
            Console.WriteLine();
            objBookDemo.bookDisplay();
            Console.WriteLine();
            Console.WriteLine("=================================================================");
            Console.WriteLine();

        }
    }
}
