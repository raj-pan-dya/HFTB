﻿/*********************************************************************
 * File                 : BooksDemo.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store book details in 2D Array.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn5
{
    class BooksDemo
    {
        private string bookTitle, bookauthor, bookpublisher, bookprice ;

        // Column name Array

        string[] columnNames = {"Book_Title", "Book_Author", "Book_Publisher", "Book_Price(Rs)" };

        string[,] objbookDetails = new string[2, 4];

        int i, j;

        // string[,] bookDetails = new string[2,4];

        private void setDetails(string title, string author, string publisher, string price)
        {
            bookTitle = title;
            bookauthor = author;
            bookpublisher = publisher;
            bookprice = price;
        }

          // Books Details Entry

        public void getBookDetails()
        {
        
            /*for (i = 0; i < columnNames.Length; i++)
            {
                Console.Write(columnNames[i]+ "\t");
               
            }*/
           
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    //Console.Write("element - [{0},{1}] : ", i, j);
                    Console.Write(columnNames[j] + ": ");
                   
                    objbookDetails[i, j] = Console.ReadLine();
                }
                Console.WriteLine();
            }

        }

        // Display Function.

        public void bookDisplay()
          {
               for (i = 0; i < 2; i++)
               {
                  for (j = 0; j < 4; j++)
                  {
                    //Console.Write("element - [{0},{1}] : ", i, j);
                   
                    Console.Write("  "+objbookDetails[i, j] + "\t\t");

                  }

                  Console.WriteLine();
               }          
          }



    }
}
