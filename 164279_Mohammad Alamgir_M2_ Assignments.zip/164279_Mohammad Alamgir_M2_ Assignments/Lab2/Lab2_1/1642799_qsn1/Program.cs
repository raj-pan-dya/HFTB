﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to calculate the square and cube of a number.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1642799_qsn1
{
    class Program
    {
        static void Main(string[] args)
        {
 
            char flag;
            do
            {
                Console.WriteLine("");
                Console.WriteLine(" =================== Menu ===================");
                Console.WriteLine(" 1. Square");
                Console.WriteLine(" 2. Cube");
                Console.WriteLine(" ============================================");

                Console.Write(" Enter your Choice: ");
            
                int choice;
                choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                int num;
                Console.Write(" Enter any number: ");
                num = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");


                int result;

                Number objNumber = new Number();

                switch (choice)
                {

                    case 1: // Square Call
                        Console.WriteLine("");
                        result = objNumber.square(num);
                        Console.WriteLine(" The Square of the number is: " + result);
                        break;

                    case 2:
                          // Cube Call 
                        Console.WriteLine("");
                        result = objNumber.cube(num);
                        Console.WriteLine(" The Cube of the number is: " + result);
                        break;

                    

                    default:
                        Console.WriteLine("");
                        Console.WriteLine("Enter the valid Input");

                        break;

                }
                Console.WriteLine("");

                Console.WriteLine(" Do you want to Continue?? Press y to Continue and n to exit.");
                flag = Convert.ToChar(Console.ReadLine());
            } while (flag == 'y');
        }


    }
}

