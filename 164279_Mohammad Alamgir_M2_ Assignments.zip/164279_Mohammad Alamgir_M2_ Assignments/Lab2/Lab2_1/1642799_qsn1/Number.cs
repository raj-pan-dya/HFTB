﻿/*********************************************************************
 * File                 : Number.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to calculate the square and cube of a number.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1642799_qsn1
{
    struct Number
    {
                 internal int num;
            
           //Square function
            internal int square(int num)
            {
                this.num = num;
                int result;
               result = this.num * this.num;
               return result;
            }

           // Cube function
           internal int cube(int num)
            {
            this.num = num;
            int result;
            result = this.num * this.num * this.num;
            return result;
            }

    }
}
