﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store products and display the same.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn4
{
    class Program
    {
        static void Main(string[] args)
        {
           ProductDemo objproductDemo = new ProductDemo();
            
            int Id, quantity;
            string name;
            double price , amount;

            Console.WriteLine(" Enter the Product Details: ");

            Console.WriteLine("");

            Console.WriteLine(" Enter the Product ID: ");
            Id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(" Enter the Product Name: ");
            name = Console.ReadLine();

            Console.WriteLine(" Enter the Product Price: ");
            price = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine(" Enter the Product Quantity: ");
            quantity = Convert.ToInt32(Console.ReadLine());

            objproductDemo.acceptDetails(id, name, price, quantity);
            Console.WriteLine("");
            Console.WriteLine(" ================ Product Details ==================");
            objproductDemo.productDisplay();
            Console.WriteLine("");
        }

       
    }
}
