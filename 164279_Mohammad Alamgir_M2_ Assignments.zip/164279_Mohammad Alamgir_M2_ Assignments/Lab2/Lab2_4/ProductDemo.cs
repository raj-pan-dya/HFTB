﻿/*********************************************************************
 * File                 : ProductDemo.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store products and display the same.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn4
{
    class ProductDemo
    {
        private Object objProductId, objProductName, objPrice, objQuantity;
        private double amountPayable;

        public void acceptDetails(int id, string name, double price, int quantity)
        {

        // Boxing Demo

            objProductId =id;
            objProductName = name;
            objPrice = price;
            objQuantity = quantity;
            amountPayable = (price*quantity);

        }

       /* public double calculateAmount()
        {
          amountPayable = objPrice*objQuantity;
            return amountPayable;
        }*/


        // Display Function
         public void productDisplay()
         {
            //Unboxing Demo

            Console.WriteLine("");

            Console.WriteLine(" Product ID: " + (int)objProductId);
            Console.WriteLine(" Product Name: " + (string)objProductName);
            Console.WriteLine(" Product Price: " + (double)objPrice);
            Console.WriteLine(" Product Quantity: " + (int)objQuantity);
            Console.WriteLine(" Product Amount to pay: " + amountPayable);

            Console.WriteLine("");
         }

        
    }
}
