﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store numbers in 2D Array.
 * Version              : 1.0
 * Last Modified Date   : 26-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_qsn2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Calling 2D Array

            twoDArray();
        }


          //2D Array Creation and storing the numbers.

        static void twoDArray()
        {
            Console.WriteLine("================ Two Dimensional Array ====================");
            Console.WriteLine(" ");

            int i, j;

            int[,] numbers = new int[5, 6];

            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 6; j++)
                {
                    Console.Write("Element - [{0},{1}] : ", i, j);
                    numbers[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.Write("\nThe matrix is : \n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("\n");
                for (j = 0; j < 6; j++)
                { 
                    Console.Write("{0}\t", numbers[i, j]);
                    
                }
           
            }

        Console.WriteLine(" ");
        }
    }

}

