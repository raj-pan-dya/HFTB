﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to implement SMS alert fascility to 
                          the customers whenever they pay the Credit
                          Card Bill for ICICI bank.
 * Version              : 1.0
 * Last Modified Date   : 30-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardBill
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            CreditCard creditCardObj = new CreditCard();

            Console.WriteLine("Enter Credit Card Detials...");
            Console.WriteLine("Enter Credit Card No.");
            creditCardObj.CreditCardNo = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Enter Credit Card Holder Name");
            creditCardObj.CardHolderName = Console.ReadLine();
            Console.WriteLine("Enter Credit amount");

            creditCardObj.BalanceAmount = Convert.ToInt32(Console.ReadLine()); ;

            //Event reference
            creditCardObj.Operation += new CreditDel(creditCardObj.GetBalance);
            Console.WriteLine("Enter Payment amount");

            int payment = Convert.ToInt32(Console.ReadLine());
            // Calling funation which contain operation event
            creditCardObj.MakePayment(payment);

        }
    }
}
