﻿
/*********************************************************************
 * File                 : ContactOps.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store the List of Contacts in binary format on
                          disk. Perform Binary Serialization to store the List.
 * Version              : 1.0
 * Last Modified Date   : 02-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{
    [Serializable]

    public class Contact
    {
        public static List<Contact> listObj = new List<Contact>();
        public static List<Contact> listObj1 = new List<Contact>();

        private int _contactNo;
        private string _contactName;
        private string _cellNo;

        public int ContactNo
        {
            get
            {
                return _contactNo;
            }
            set
            {
                _contactNo = value;
            }
        }

        public string ContactName
        {
            get
            {
                return _contactName;
            }
            set
            {
                _contactName = value;
            }
        }

        public string CellNo
        {
            get
            {
                return _cellNo;
            }
            set
            {
                _cellNo = value;
            }
        }


    }
}
