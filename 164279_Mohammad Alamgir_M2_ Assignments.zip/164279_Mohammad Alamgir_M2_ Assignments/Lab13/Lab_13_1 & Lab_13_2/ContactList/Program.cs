﻿
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store the List of Contacts in binary format on
                          disk. Perform Binary Serialization to store the List.
 * Version              : 1.0
 * Last Modified Date   : 02-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{
    class Program
    {
        static List<Contact> contact = new List<Contact>();
        static void Main(string[] args)
        {
            
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice: ");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());


                switch (taskFlag)
                {

                    case 1:
                        //ADD
                        ContactOps.AddContact();
                        break;

                    case 2:
                        //Serialize 
                        //Solution of Lab 13_1
                        ContactOps.SerializeListBF();                       
                        break;

                    case 3:
                        //Solution of Lab 13_1
                        contact = ContactOps.DeSerializeListBF();                    
                        break;

                    case 4:
                        //Solution of Lab 13_1
                        ContactOps.ShowAllContacts(contact);

                        break;

                    default:                        
                        Console.WriteLine("Enter Correct Choice.");
                        break;

                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit.");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');
        }

        static void PrintMenu()
        {
            Console.WriteLine("****************************************");
            Console.WriteLine("Press 1 to Add Contact");
            Console.WriteLine("Press 2 to Serialize List using BF");
            Console.WriteLine("Press 3 to DeSerialize List using BF");
            Console.WriteLine("Press 4 to Show All DeSerialize list Contacts");
            Console.WriteLine("****************************************");
        }

    }
}
