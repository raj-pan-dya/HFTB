﻿
/*********************************************************************
 * File                 : ArithematicOperation.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to perform Arithmetic operations on two 
                          numbers. The operations include Add Numbers,
                          Multiply Numbers, Divide Numbers, Subtract Numbers 
                          and Find Max Number using Delegates.
 * Version              : 1.0
 * Last Modified Date   : 30-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates

{
    public delegate double newDelegate(double num_1, double num_2);
    class ArithmeticOperation
    {
       
        public double Add(double a, double b)
        {
            double result = a + b;
            return result;
        }
        public double Subtract(double a, double b)
        {
            double result = a - b;
            return result;
        }
        public double Multiply(double a, double b)
        {
            double result = a * b;
            return result;
        }
        public double Divide(double a, double b)
        {
            double result = a / b;
            return result;
        }
        public double Max(double a, double b)
        {
            double result;
            if (a > b)
            {
                result = a;
            }
            else
            {
                result = b;
            }
            return result;
        }
        
        public static double PerformArithmeticOperation(int num1, int num2, newDelegate arOperation) {
            double result;
            result = arOperation.Invoke(num1, num2);
            return result;
        }

    }
}

