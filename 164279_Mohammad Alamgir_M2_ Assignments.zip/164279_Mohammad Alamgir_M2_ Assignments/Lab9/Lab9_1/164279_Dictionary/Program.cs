﻿
/*********************************************************************
 * File                 : 164279_Dictionary(Program.cs)
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to create a string dictionary.
 * Version              : 1.0
 * Last Modified Date   : 30-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _164279_Dictionary
{
    class Program
    {
        //Dictionary Creation with string keys

        static Dictionary<string, string> objDictionary = new Dictionary<string, string>();

        //Main Method

        static void Main(string[] args)
        {

            int choice;

            do
            {
                printMenu();
                Console.WriteLine();

                Console.Write(" Enter your Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        addElements();
                        break;

                    case 2:
                        throwExceptionForSameKey();
                        break;

                    case 3:
                        updateDictionary();
                        break;

                    case 4:
                        handlingExceptionForNoKey();
                        break;

                    case 5:
                        displayDictionary();
                        break;

                    case 6:
                        removeElemnt();
                        break;

                    case 7: //Exit
                        return;

                    default:
                        Console.WriteLine(" Invalid Choice");
                        break;
                }

            } while (choice != -1);


        }

        // MenuPrint
        static void printMenu()
        {
            Console.WriteLine();
            Console.WriteLine(" ==================== Menu ====================");
            Console.WriteLine(" 1. Add Elements in the Dictionary");
            Console.WriteLine(" 2. ExceptionCheck when we add elements with same key");
            Console.WriteLine(" 3. Dictionary update ");
            Console.WriteLine(" 4. Handling Exception");
            Console.WriteLine(" 5. Display Dictionary");
            Console.WriteLine(" 6. Remove Element");
            Console.WriteLine(" 7. Exit");
            Console.WriteLine(" ==============================================");
        }

        // Adding elements to the Dictionary

        public static void addElements()
         {
            objDictionary.Add(" txt", " Alamgir.exe");
            objDictionary.Add(" odt", " OpenOffice.exe");
            objDictionary.Add(" pdf", " PDF.exe");
            objDictionary.Add(" tex", " Latex.exe");
            objDictionary.Add(" doc", " PDF.exe");
         }

        //This Exception will throw Exception when we add element with same keyword.

        public static void throwExceptionForSameKey()
        {
            Console.WriteLine();
            try
            {
                objDictionary.Add(" txt", " xyz.exe");
            }
            catch (ArgumentException)
            {
                Console.WriteLine(" An element with Key = \"txt\" already exists.");
            }
        }

        //  using indexer to change the value associated with a key.

        public static void updateDictionary()
        {
            Console.WriteLine();
           
            objDictionary["pdf"] = "winword.exe";

            Console.WriteLine(" For key = \"pdf\", value = {0}.", objDictionary["pdf"]);

            // If a key does not exist, setting the indexer for that key Adding a new key value pair.

            objDictionary["rtf"] = "TextFormat.exe";

        }


      //Handling the above Exception using TryGetValue function.

        public static void handlingExceptionForNoKey()
        {

            Console.WriteLine();

            string value = "";

            if (objDictionary.TryGetValue("tif", out value))
            {
                Console.WriteLine( " For key = \"tif\", value = {0}.", value);
            }
            else
            {
                Console.WriteLine(" Key = \"tif\" is not found.");
            }
        }


        // Data retrieving using foreach to enumerate dictionary elements, the elements are retrieved as Key/Value
        // Pair objects. Use a foreach loop to print the values and test this.

        public static void displayDictionary()
        {
            Console.WriteLine();
            Console.WriteLine(" Elements of the Dictionary: ");
            Console.WriteLine();

            foreach (KeyValuePair<string, string> keyValuePair in objDictionary)
            {

                Console.WriteLine(" Key = {0}, Value = {1}", keyValuePair.Key, keyValuePair.Value);

            }

        }



        // Use the Remove method to remove a key/value pair.
        public static void removeElemnt()
        {

            Console.WriteLine();

            if (!objDictionary.ContainsKey("txt"))
            {
                Console.WriteLine("Key \"txt\" is not found.");
            }

            Console.WriteLine("\nRemove(\"txt\")");

            objDictionary.Remove("txt");

          

        }

    }
}

    

