﻿
/*********************************************************************
 * File                 : InvalidCreditLimitExp.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : ABC Corp wants to maintain list of Customers. 
                          While accepting the data, you need to validate
                          CreditLimit property. If the value is invalid, 
                          you need to raise Exception. We need to implement 
                          custom exception class to implement the same.
 * Version              : 1.0
 * Last Modified Date   : 28-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class InvalidCreditLimitExp : ApplicationException
    {
        public InvalidCreditLimitExp()
            : base()
        {

        }
        public InvalidCreditLimitExp(string message)
            : base(message)
        {

        }
    }
}
