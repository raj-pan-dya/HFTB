﻿

/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : ABC Corp wants to maintain list of Customers. 
                          While accepting the data, you need to validate
                          CreditLimit property. If the value is invalid, 
                          you need to raise Exception. We need to implement 
                          custom exception class to implement the same.
 * Version              : 1.0
 * Last Modified Date   : 28-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomerInfo();
        }

        public static void CustomerInfo()
        {
            Customer objCustomer = new Customer();
            try
            {
                Console.WriteLine("Enter the details of Customer");
                Console.WriteLine("");
                Console.Write("Enter Customer Id: ");
                objCustomer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name: ");
                objCustomer.CustomerName = Console.ReadLine();
                Console.Write("Enter Customer Address: ");
                objCustomer.Address = Console.ReadLine();
                Console.Write("Enter City: ");
                objCustomer.City = Console.ReadLine();
                Console.Write("Enter Customer Phone: ");
                objCustomer.Phone = Console.ReadLine();
                Console.Write("Enter CreditLimit: ");
                objCustomer.CreditLimit = Convert.ToInt32(Console.ReadLine());

                Customer.ValidateCredit(objCustomer.CreditLimit);

                Console.WriteLine("");
            }
            catch (InvalidCreditLimitExp objEx)
            {

                Console.WriteLine(objEx.Message);
            }
        }
    }
}
