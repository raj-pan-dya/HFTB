﻿
/*********************************************************************
 * File                 : Customer.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : ABC Corp wants to maintain list of Customers. 
                          While accepting the data, you need to validate
                          CreditLimit property. If the value is invalid, 
                          you need to raise Exception. We need to implement 
                          custom exception class to implement the same.
 * Version              : 1.0
 * Last Modified Date   : 28-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Customer
    {
        int _customerId;
        string _customerName;
        string _address;
        string _city;
        string _phone;
        int _creditLimit;

        public int CustomerId
        {
            get { return _customerId; }
            set { _customerId = value; }
        }
        public string CustomerName
        {
            get { return _customerName; }
            set { _customerName = value; }
        }
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        public string City
        {
            get { return _city; }
            set { _city = value; }
        }
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }
        public int CreditLimit
        {
            get { return _creditLimit; }
            set { _creditLimit = value; }
        }


        public Customer()
        {
           
        }

        public Customer(int CustomerId, string CustomerName, string Address, string City, string Phone, int CreditLimit)
        {
            this.CustomerId = CustomerId;
            this.CustomerName = CustomerName;
            this.Address = Address;
            this.City = City;
            this.Phone = Phone;
            this.CreditLimit = CreditLimit;
             
        }

        public static void ValidateCredit(int CreditLimit)
        {
            if (CreditLimit > 50000)
            {
                throw new InvalidCreditLimitExp("Credit Limit Exceeded!!!!!");
            }
        }
    }
}


