﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : ABC Corp wants to maintain list of Customers. 
                          While accepting the data, you need to validate
                          CreditLimit property. If the value is invalid, 
                          you need to raise Exception. We need to implement 
                          custom exception class to implement the same.
 * Version              : 1.0
 * Last Modified Date   : 28-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductTest
{
    class Program
    {

        static void Main(string[] args)
        {
            try
            {
                ProductMock obP = GetProductDetails();
                DisplayDetails(obP);
            }
            catch (DataEntryException objExp)
            {
                Console.WriteLine(objExp.Message);
            }
}

        public static ProductMock GetProductDetails()
        {
            ProductMock objProduct = new ProductMock();
           
                Console.WriteLine("Enter the Details of Products");
               
                Console.Write("Enter the Product ID: ");
                objProduct.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the Product Name: ");
                objProduct.ProductName = Console.ReadLine();
                Console.Write("Enter the Product Price: ");
                objProduct.Price = Convert.ToInt32(Console.ReadLine());
                ProductMock.ValidateId(objProduct.ProductId);

            return objProduct;

        }

        public static void DisplayDetails(ProductMock product)
        {
            Console.WriteLine(product.ProductId + " " + product.ProductName);
        }
    }
}
