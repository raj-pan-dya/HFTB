﻿
/*********************************************************************
 * File                 : Shape.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to create Circle and Triangle class by
                          inheriting the Shape Class.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public class Shape
    {
        public virtual void WhoamI()
        {
            Console.WriteLine("I m Shape");
        }
    }
}
