﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to create Circle and Triangle class by
                          inheriting the Shape Class.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape s;
            Circle c;
            //stores object of triangle class.
            s = new Triangle();
            s.WhoamI();

            //stores object of Circle class.
            s = new Circle();
            s.WhoamI();

            //calls WhoamI() of Circle class.
            c = new Circle();
            c.WhoamI();
            Console.ReadKey();
        }
    }
}
