﻿/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to store numbers in 2D Array.
 * Version              : 1.0
 * Last Modified Date   : 27-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            PermanentEmployee permanentEmployee;
            ContractEmployee contractEmployee;
            int option;
            Console.WriteLine("*******Employee System*********");
            Console.Writeline();
            Console.WriteLine("Select type of Employee:\n 1)Permanent Employee\n 2)Contract Employee");
            option = Convert.ToInt32(Console.ReadLine());
            switch (option)
            {
                case 1://Permanent Employee Entry

                    permanentEmployee = new PermanentEmployee();
                    Console.WriteLine("Enter Employee details:");
                    Console.WriteLine("Employee Id:");
                    permanentEmployee.id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Employee Name:");
                    permanentEmployee.name = Console.ReadLine();
                    Console.WriteLine("Employee Address:");
                    permanentEmployee.add = Console.ReadLine();
                    Console.WriteLine("Employee City:");
                    permanentEmployee.city = Console.ReadLine();
                    Console.WriteLine("Employee Department:");
                    permanentEmployee.dept = Console.ReadLine();
                    Console.WriteLine("Employee Salary:");
                    permanentEmployee.sal = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Employee ProvidendFund:");
                    permanentEmployee._ProvidendFund = Convert.ToDouble(Console.ReadLine());
                    permanentEmployee.PrintEmployees();
                    Console.WriteLine("Salary: " + permanentEmployee.getSalary());

                    break;
                case 2: //Contract Employee
                    contractEmployee = new ContractEmployee();
                    Console.WriteLine("Enter Employee details:");
                    Console.WriteLine("Employee Id:");
                    contractEmployee.id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Employee Name:");
                    contractEmployee.name = Console.ReadLine();
                    Console.WriteLine("Employee Address:");
                    contractEmployee.add = Console.ReadLine();
                    Console.WriteLine("Employee City:");
                    contractEmployee.city = Console.ReadLine();
                    Console.WriteLine("Employee Department:");
                    contractEmployee.dept = Console.ReadLine();
                    Console.WriteLine("Employee Salary:");
                    contractEmployee.sal = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Employee Peark:");
                    contractEmployee._Perks = Convert.ToDouble(Console.ReadLine());
                    contractEmployee.PrintEmployees();
                    Console.WriteLine("Salary: "+ contractEmployee.getSalary());

                    break;
                default:
                    Console.WriteLine("Enter valid option");
                    break;
            }

            Console.ReadLine();
            
        }
    }
}
