﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Question1
{
   public class ContractEmployee : EmployeeClass
    {
        double Perks;

        public double _Perks
        {
            get
            {
                return Perks;
            }
            set
            {
                Perks = value;
            }
        }

        //override method of base class.
        public override double getSalary()
        {
            EmpSalary = EmpSalary + Perks;
            return sal;
        }
    }
}
