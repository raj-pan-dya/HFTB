﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AlamQsn2Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        int id;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

       

       

        public void PopulateUI()
        {
            //List<Product> prods = dbContext.Products.ToList();
            //var res = prods.OrderByDescending(s => s.Id);
            //txtProductGrid.ItemsSource = prods;
            //ComboName.ItemsSource = prods;
            //ComboName.DisplayMemberPath = "ProdName";

            List<Product> prods = dbContext.Products.ToList();
            var res = prods.Where(s => s.Price > 20);

            txtProductGrid.ItemsSource = res;
            ComboName.ItemsSource = res;
            ComboName.DisplayMemberPath = "ProdName";



        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            id = ((Product)ComboName.SelectedItem).Id;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {

            // Write Code to get Data from Controls & set to Properties Of Product

            Product prod = new Product
            {
                ProdName = ComboName.Text,
                Price = Convert.ToDecimal(txtPrice.Text),
                ExpiraryDate = Convert.ToDateTime(txtDate.Text)
            };

            dbContext.Products.Add(prod);
            dbContext.SaveChanges();
            MessageBox.Show(" Product Inserted ");
            PopulateUI();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            Product prod = dbContext.Products.Single(p => p.Id == id);

            //Product prod = (Product)ComboName.SelectedItem;


            prod.ProdName = ComboName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpiraryDate = Convert.ToDateTime(txtDate.Text);


            dbContext.SaveChanges();
            MessageBox.Show(" Product Updated ");
            PopulateUI();
        }


        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            int id = ((Product)txtProductGrid.SelectedItem).Id;
            Product prod = dbContext.Products.Single(p => p.Id == id);

            //Product prod = (Product)ComboName.SelectedItem;

            dbContext.Products.Remove(prod);
            dbContext.SaveChanges();
            MessageBox.Show(" Product Deleted ");
            PopulateUI();
        }

    }
}
