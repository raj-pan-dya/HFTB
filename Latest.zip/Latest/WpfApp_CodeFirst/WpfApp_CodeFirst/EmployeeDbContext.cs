﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_CodeFirst
{
    public class EmployeeDbContext : DbContext
    {
        public EmployeeDbContext() : base("name=Training_24Oct18_Pune") { }

        public virtual DbSet<Employee_279> Employees { get; set; }
    }
}
