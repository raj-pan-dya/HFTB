﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WpfApp_CodeFirst
{
    public class Employee_279
    {
        //EmpId, EmpName, DeptId , Salary
          [Key]
            public int EmpId
            {
            get; set;
            }

           public string Name
           {
            get; set;
           }

        public int DeptId
        {
            get; set;
        }

        public int Salary
        {
            get; set;
        }
    }
}

