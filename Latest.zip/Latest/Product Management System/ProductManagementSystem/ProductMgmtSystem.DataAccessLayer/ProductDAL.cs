﻿
// /<Summary>
/*********************************************************************
 * File                 : ProductDAL.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the functions of Data Access.
 * Version              : 1.0
 * Last Modified Date   : 11-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization;
//using System.Configuration;
using ProductMgmtSystem.Entities;
using ProductMgmtSystem.Exceptions;

namespace ProductMgmtSystem.DataAccessLayer
{
    public class ProductDAL
    {
        // Decleration Of SqlConnection Object Reference 

        SqlConnection cn = null;

        // Decleration Of Sql Command Object Reference

       SqlCommand cmd = null;

        // Decleration Of Sql Command Object Reference

        SqlDataReader dr = null;

        // Constructor for Connection

        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);

        }

        // public static List<Product> productList = new List<Product>();

        // Function to insert new Products.

        public bool InsertDAL(Product product)
        {
            bool isInserted = false;

            try
            {
                // cmd = new SqlCommand(" insert into Alamgir.Product values (@pName, @price, @expDate)", cn);

                cmd = new SqlCommand("[Alamgir].[USP_InsertProduct]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@expDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }

            catch (ProductExceptions udObj)
            {
                throw udObj;
            }

            catch (Exception ObjEx)
            {
                throw ObjEx;
            }



            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }

            return isInserted;

        }

        // Function to update a product

        public bool UpdateDAL(Product product)
        {
            bool isUpdated = false;

            try
            {
                //cmd = new SqlCommand("update [Alamgir].[Product] set ProdName=@pName, Price=@price, ExpDate=@eDate where Id=@id", cn);
                cmd = new SqlCommand("[Alamgir].[USP_UpdateProduct]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@expDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
            }
            catch (ProductExceptions ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

            return isUpdated;
        }

        // Function to delete a Product

        public bool DeleteDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                //cmd = new SqlCommand("update [Alamgir].[Product] set ProdName=@pName, Price=@price, ExpDate=@eDate where Id=@id", cn);

                cmd = new SqlCommand("[Alamgir].[USP_DeleteProduct]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);

                cn.Open();
                cmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (ProductExceptions ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

            return isDeleted;
        }
         
         // Function to Select All Products

        public IEnumerable<Product> SelectAllDAL()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand("select * from [Alamgir].[Product]", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return products;
        }


    }
}
