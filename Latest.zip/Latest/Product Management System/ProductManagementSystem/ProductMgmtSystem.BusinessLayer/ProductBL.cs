﻿// /<Summary>
/*********************************************************************
 * File                 : ProductBL.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to write the logic of Product Entry.
 * Version              : 1.0
 * Last Modified Date   : 11-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductMgmtSystem.Entities;
using ProductMgmtSystem.Exceptions;
using ProductMgmtSystem.DataAccessLayer;

namespace ProductMgmtSystem.BusinessLayer
{
    public class ProductBL
    {
        // Function to validate the Input
       
        private static bool ValidateProduct(Product product)
        {
            StringBuilder sb = new StringBuilder();
            bool validProduct = true;

            if (product.ProdName.Length < 1)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + " Invalid Product Name");

            }
            if (product.Price < 0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Price");

            }
            if (product.ExpDate.Year <= ( DateTime.Now.Year))
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Product Expiry not valid");
            }

            if (validProduct == false)
                throw new ProductExceptions(sb.ToString());
            return validProduct;
        }

        // BL Function to Insert Product

        public bool InsertBL(Product product)
        {
            bool productInserted = false;
            try
            {
                if (ValidateProduct(product))
                {
                    ProductDAL productDAL = new ProductDAL();
                    productInserted = productDAL.InsertDAL(product);
                }
            }
            catch (ProductExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return productInserted;
        }

        //BL Function to update Product

        public bool UpdateBL(Product product)
        {
            bool productUpdated = false;
            try
            {
                if (ValidateProduct(product))
                {
                    ProductDAL productDAL = new ProductDAL();
                    productUpdated = productDAL.UpdateDAL(product);
                }
            }
            catch (ProductExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return productUpdated;
        }

        //BL Function to delete Product

        public bool DeleteBL(int id)
        {
            bool productDeleted = false;
            try
            {
               
                    ProductDAL productDAL = new ProductDAL();
                    productDeleted = productDAL.DeleteDAL(id);
               
            }
            catch (ProductExceptions objex)
            {
                throw objex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return productDeleted;
        }

        //BL Method to populate the grid

        public IEnumerable<Product> SelectAllBL()
        {
            IEnumerable<Product> products = null;
            try
            {

                ProductDAL productDAL = new ProductDAL();
                products = productDAL.SelectAllDAL();

            }
            catch (ProductExceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }

            return products;

        }
    }
}
