﻿create Table [Alamgir].[Employee]
(
   EmpId int IDENTITY NOT NULL,
   EmpName varchar (20),
   DeptId int,
   Salary money
);

 select * from [Alamgir].[Employee];

 exec sp_help [Alamgir.Employee];


 insert into [Alamgir].[Employee] values
 ( 'Alamgir', 101, 100000 ),
 ( 'Ramu', 106, 500000 ),
 ( 'Zaid', 109, 800000 );