﻿

// /<Summary>
/*********************************************************************
 * File                 : ProductMgmtSystem.xaml
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to design GUI and Performing the Operations.
 * Version              : 1.0
 * Last Modified Date   : 11-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summar

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProductMgmtSystem.Entities;
using ProductMgmtSystem.Exceptions;
using ProductMgmtSystem.DataAccessLayer;
using ProductMgmtSystem.BusinessLayer;

namespace ProductMgmtSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        ProductBL pBl = new ProductBL();
        Product p = null;

        // Default Constructor

        public MainWindow()
        {
            InitializeComponent();
        }

        // Populating GUI

        public void PopulateUI()
        {
            try
            {
                IEnumerable<Product> prods = pBl.SelectAllBL();

                txtTotalCount.Text = prods.Count().ToString();
                var res = from s in prods select s.Id;
                txtMaxId.Text = (res.Max()+1) .ToString();
                txtProductGrid.ItemsSource = prods;
                ComboName.ItemsSource = prods;
                ComboName.DisplayMemberPath = "ProdName";
            }

            catch (ProductExceptions ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

       // Method to Validate the Window

        public bool IsInputValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (ComboName.Text == null | ComboName.Text == string.Empty)
            {
                sb.Append("\nProduct Name is Mandatory!");
                isValid = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (txtDate.Text == null | txtDate.Text == string.Empty)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new ProductExceptions(sb.ToString());
            }

            return isValid;
        }

        // Method to Load Window

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        // Method For Edit Button

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            p = (Product)ComboName.SelectedItem;
        }

        // Method to insert new product in the Table

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsInputValid())
                {
                    Product p = new Product
                    {
                        ProdName = ComboName.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(txtDate.Text)
                    };

                    pBl.InsertBL(p);
                    MessageBox.Show(" Product inserted Successfully..!!");

                    PopulateUI();
                }
            }
            catch (ProductExceptions ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        // Method to update the Product

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Product p = (Product)ComboName.SelectedItem;
                p.ProdName = ComboName.Text.ToString();
                p.Price = Convert.ToDecimal(txtPrice.Text);
                p.ExpDate = Convert.ToDateTime(txtDate.Text);

                pBl.UpdateBL(p);
                MessageBox.Show(" Product Updated Successfully..!!");

                PopulateUI();

            }
            catch (ProductExceptions ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        // Method to delete the Product

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                p = (Product)ComboName.SelectedItem;
                pBl.DeleteBL(p.Id);
                MessageBox.Show(" Product Deleted Successfully..!!");

                PopulateUI();


            }
            catch (ProductExceptions ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }
    }
}
