﻿// /<Summary>
/*********************************************************************
 * File                 : Product.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the Entities Of product Class.
 * Version              : 1.0
 * Last Modified Date   : 11-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
 ///</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductMgmtSystem.Entities
{
    public class Product
    {
           // Property Definition 

            private int _id;
            public int Id
            {
              get
              {
                return _id;
              }
              set
              {
                _id = value;
              }
            }
            private string _prodName;
            public string ProdName
            {
              get
              {
                return _prodName;
               }
              set
              {
                _prodName = value;
               }
            }

            private decimal _price;
            public decimal Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }

            private DateTime _expDate;
            public DateTime ExpDate
        {
            get
            {
                return _expDate;
            }
            set
            {
                _expDate = value;
            }
        }

        //public decimal Price { get; set; }
        //public DateTime ExpDate { get; set; }

    }
}
