﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AdoDisArch_pfApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataSet ds = new DataSet();
        
        public MainWindow()
        {
            InitializeComponent();
        }

        public void FillDataSet()
        {            
            cmd = new SqlCommand("select * from amol.product", cn);
            da = new SqlDataAdapter(cmd);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds, "prd");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {           
            FillDataSet();
            PopulateUI();
            //MessageBox.Show("Rows Count: "+ds.Tables["prd"].Rows.Count.ToString());
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            DataRow r = ds.Tables["prd"].NewRow();
            r[1] = cmbProdName.Text;
            r[2] = Convert.ToDecimal(txtPrice.Text);
            r[3] = Convert.ToDateTime( dpExpDate.Text);
            ds.Tables["prd"].Rows.Add(r);
            MessageBox.Show("Inserted!");
            PopulateUI();
        }

        private void PopulateUI()
        {
            dgProducts.ItemsSource = ds.Tables["prd"].DefaultView;
            cmbProdName.ItemsSource = ds.Tables["prd"].DefaultView;
            cmbProdName.DisplayMemberPath = "ProdName";
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {            
            DataRowView v = (DataRowView)cmbProdName.SelectedItem;
            int id = Convert.ToInt32(v[0]);
            DataRow r = ds.Tables["prd"].Rows.Find(id);
            r[1] = cmbProdName.Text;
            r[2] = Convert.ToDecimal(txtPrice.Text);
            r[3] = Convert.ToDateTime(dpExpDate.Text);
            MessageBox.Show("Updated!");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DataRowView v = (DataRowView)cmbProdName.SelectedItem;
            int id = Convert.ToInt32(v[0]);
            ds.Tables["prd"].Rows.Find(id).Delete();            
            MessageBox.Show("Deleted!");
            PopulateUI();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUpdateDB_Click(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder cb = new SqlCommandBuilder(da);            
            da.Update(ds, "prd");
            MessageBox.Show("All Records Updated!"); 
        }
    }
}
