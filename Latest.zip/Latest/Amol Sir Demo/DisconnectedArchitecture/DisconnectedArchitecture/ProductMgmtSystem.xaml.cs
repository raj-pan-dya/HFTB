﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows;
using System.Configuration;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DisconnectedArchitecture
{
    /// <summary>
    /// Interaction logic for ProductMgmtSystem.xaml
    /// </summary>
    public partial class ProductMgmtSystem : Window
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataSet ds = new DataSet();
       // DataRowView v = null;

        public ProductMgmtSystem()
        {
            InitializeComponent();
        }

        public void FillDataSet()
        {
            cmd = new SqlCommand("select * from [Alamgir].[Product]", cn);
            da = new SqlDataAdapter(cmd);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds, "Alam");
        }

        private void PopulateUI()
        {
            txtProductGrid.ItemsSource = ds.Tables["Alam"].DefaultView;
            ComboName.ItemsSource = ds.Tables["Alam"].DefaultView;
            ComboName.DisplayMemberPath = "ProdName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillDataSet();
            PopulateUI();
            //MessageBox.Show("Rows Count: "+ds.Tables["prd"].Rows.Count.ToString());
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            DataRow r = ds.Tables["Alam"].NewRow();
            r[1] = ComboName.Text;
            r[2] = Convert.ToDecimal(txtPrice.Text);
            r[3] = Convert.ToDateTime(txtDate.Text);
            ds.Tables["Alam"].Rows.Add(r);
            MessageBox.Show("Product inserted Successfully !!!!");
            PopulateUI();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            DataRowView v = (DataRowView)ComboName.SelectedItem;
            int id = Convert.ToInt32(v[0]);
            DataRow r = ds.Tables["Alam"].Rows.Find(id);
            r[1] = ComboName.Text;
            r[2] = Convert.ToDecimal(txtPrice.Text);
            r[3] = Convert.ToDateTime(txtDate.Text);
            MessageBox.Show("Product updated Successfully !!!!");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DataRowView v = (DataRowView)ComboName.SelectedItem;
            int id = Convert.ToInt32(v[0]);
            ds.Tables["Alam"].Rows.Find(id).Delete();
            MessageBox.Show(" Product deleted Successfully !!!!");
            PopulateUI();
        }

        private void btnUpdateDB_Click(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(ds, "Alam");
            MessageBox.Show("All Records Updated!");
        }

    
    }
}
