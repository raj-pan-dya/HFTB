﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQDemo
{
    class Student
    {
        public int RollNo { set; get; }

        public string Name { set; get; }

        public int[] Marks { set; get; }

        public int Age { set; get; }


        // Collection Initialiser
        public static List<Student> GetAll()
        {
            List<Student> studs = new List<Student>
            {
            new Student { RollNo = 101 , Name = "Sushant" , Age = 19,  Marks = new int[] { 70, 80, 77, 88} },
            new Student { RollNo = 102 , Name = "Neena" , Age = 21, Marks = new int[] { 80, 66, 99, 88} },
            new Student { RollNo = 104 , Name = "Sushant" , Age = 21,  Marks = new int[] { 80, 80, 87, 88} },
            new Student { RollNo = 106 , Name = "Zaid" , Age = 23, Marks = new int[] { 90, 97, 77, 68} },
            new Student { RollNo = 105 , Name = "Rahul" , Age = 23, Marks = new int[] { 90, 97, 77, 68} }
            };

              return studs;
         }
    }
    
}
