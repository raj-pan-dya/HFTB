﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            int[] number = { 01, 20, 22, 56, 31, 16, 17, 9, 23};

            //// Declarative Query Syntax

            //var res = from n in number
            //          where (n % 2 == 0)
            //          select n;

           
            /// Syntax using Extension Method (Lambda Method)

            var res = number.Where(n => n % 2 == 0);

            foreach (var i in res)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("\n");

            number[1] = 9;

            foreach (var i in res)
            {
                Console.WriteLine(i);
            }*/

            List<Student> studs = Student.GetAll();
            // select RollNo, Name from Students

            //var res1 = from s in studs
            //           select new { s.RollNo, s.Name };

            //foreach (var r in res1)
            //{
            //    Console.WriteLine(r.RollNo + ", " + r.Name);
            //}

            //Console.WriteLine();

            //// Marks in three lines
            //var res2 = from s in studs
            //           select s.Marks;

            //foreach (var item in res2)
            //{
            //    Console.WriteLine(item);
            //}

            //Console.WriteLine();

            ////Get All Marks Togethor

            //var res3 = from s in studs
            //           from m in s.Marks
            //           select m;

            //foreach (var item in res3)
            //{
            //    Console.Write(item + " ");
            //}

            //Console.WriteLine();

            ////Get All Marks Togethor by Extension method

            //Console.WriteLine();

            //var res4 = studs.SelectMany(s => s.Marks );


            //foreach (var item in res4)
            //{
            //    Console.Write(item + " ");
            //}
            //Console.WriteLine();
            //// List out All the Students order by their names Ascending
            //Console.WriteLine();
            //var res5 = from s in studs
            //           orderby s.Name ascending
            //           select s;

            //foreach (var item in res5)
            //{
            //    Console.Write(item.Name + " ");
            //}
            //Console.WriteLine();
            //// List out All the Students order by their names Descending
            //Console.WriteLine();
            //var res6 = from s in studs
            //           orderby s.Name descending
            //           select s;

            //foreach (var item in res6)
            //{
            //    Console.Write(item.Name + " ");
            //}
            //Console.WriteLine();
            //Console.WriteLine();

            //Byte Using Extension method

            //var res7 = studs.OrderBy(s => s.Name);


            //foreach (var item in res7)
            //{
            //    Console.Write(" " + item.Name + " ");
            //}

            //Console.WriteLine();
            //Console.WriteLine();

            // Using thenby

            //var res8 = studs.OrderBy(s => s.Name).ThenBy(s => s.Age);


            //foreach (var item in res8)
            //{
            //    Console.Write(" "+ item.RollNo + " " + item.Name + " \n");
            //}
            //Console.WriteLine();
            //Console.WriteLine();

            // Using Group by age

            //var res1 = from s in studs
            //           group s by s.Age;

            //foreach (var item in res1)
            //{
            //    Console.Write( " Age " + item.Key + "\n" );
            //}
            //Console.WriteLine();
            //Console.WriteLine();

            // Using Group by age and Name

            //var res2 = from s in studs
            //           group s by s.Age;

            //foreach (var item in res1)
            //{
            //    Console.Write(" Age " + item.Key + " group:- \n\n");

            //    foreach (var s in item)
            //    {
            //        Console.Write( " "+ s.RollNo + " " + s.Name + " " + s.Age + "\n");
            //      // Console.WriteLine();
            //    }
            //    Console.WriteLine();
            //}


            //Console.WriteLine();
            //Console.WriteLine();

            // Set Operator

            //int[] arr1 = { 60 , 50 , 1 , 80 , -87, 7, 90 , 60 };
            //int[] arr2 = { 5, 70, 40, 1, 80, -87, 7, 90, 60 };

            //var result = arr1.Union(arr2);
            //Console.Write(" Union Of two Arrays: ( ");
            //foreach (var item in result)
            //{
            //    Console.Write( item + " ");
            //}
            //Console.Write(" )");
            //Console.WriteLine();
            //var result1 = arr1.Intersect(arr2);

            //Console.Write(" Intersection Of Two Arrays: (");
            //foreach (var item in result1)
            //{
            //    Console.Write( item + " ");
            //}
            //Console.Write(" )");

            //Console.WriteLine();
            //var result2 = arr1.Except(arr2);
            //Console.Write(" Exception Of Two Arrays: (");
            //foreach (var item in result2)
            //{
            //    Console.Write( item + " " );
            //}

            Console.WriteLine();

            // Conversion Operator

            //int[] arr1 = { 60, 50, 1, 80, -87, 7, 90, 60 };
            //int[] arr2 = { 5, 70, 40, 1, 80, -87, 7, 90, 60 };

            //Object[] objs = { 1, 'C', " Hello " , 1.5 , 5 , "Hii" + 'A'};

            //var elms = objs.OfType<int>();

            //foreach (var item in elms)
            //{
            //    Console.Write(item + " ");
            //}

            //Console.WriteLine();
            //var elms1 = objs.OfType<string>();

            //foreach (var item in elms1)
            //{
            //    Console.Write(item + " ");
            //}

            // Aggregate Operators

            //Console.WriteLine("Max: " + arr1.Max()+ " Min: " + arr1.Min() + " Sum: " + arr1.Sum() + " Average: " + arr1.Average());

            // Element Operator

            //int[] arr1 = { 60, 50, 1, 80, -87, 7, 90, 90 };
            //int[] arr2 = new int[0];

            //Console.WriteLine("Fisrt: " + arr1.First());
            //Console.WriteLine("Last: " + arr1.Last());
            //Console.WriteLine("FirstOrDefault: " + arr1.FirstOrDefault());
            //Console.WriteLine("LastOrDefault: " + arr1.LastOrDefault());

            //Console.WriteLine("Single: " + arr2.Single());

            // Get the RollNo, Name Of Students starting nmae with 'Z'

            // Using Lamda Extension

            //var name = studs.Where( s => s.Name.StartsWith("S")).Select(s => new {s.RollNo , s.Name , s.Age});

            //foreach (var item in name)
            //{
            //    Console.Write(item.RollNo + " "+ item.Name + " " + item.Age + "\n");
            //}


            // Using Lamda Extension

            var name = from s in studs
                       where s.Name.StartsWith("S")
                       select new { s.RollNo, s.Name, s.Age }
                       ;

            foreach (var item in name)
            {
                Console.Write(item.RollNo + " " + item.Name + " " + item.Age + "\n");
            }
            Console.WriteLine();
            Console.WriteLine();

            // Finding Average Of Marks Of Students

            var name1 = from s in studs
                        select new {s.Marks, s.Name};
                     

            foreach (var item in name1)
            {
                Console.Write( " "+item.Name+ ": A" +item.Marks.Average() + "\n");
            }

            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
