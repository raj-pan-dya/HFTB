﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication1
{
    class BankAccount
    {
        public int AccNo { get; set; }
        public string AccHolderName { get; set; }
        public decimal CurBalance { get; set; }
    }
}
