﻿
// /<Summary>
/*********************************************************************
 * File                 : CustomerBL.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the Customer functions of Business Layer.
 * Version              : 1.0
 * Last Modified Date   : 14-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GharKaKhanaMgmtSystem.Entities;
using GharKaKhanaMgmtSystem.Exceptions;
using GharKaKhanaMgmtSystem.DataAccessLayer;

namespace GharKaKhanaMgmtSystem.BusinessLayer
{
    public class CustomerBL
    {

        // Function to validate customer
        private static bool ValidateCust(Customer customer)
        {
            StringBuilder sb = new StringBuilder();

            bool validCust = true;

            if (customer.CustName == "[A-za-z]")
            {
                validCust = false;
                sb.Append(Environment.NewLine + " Customer name is not valid");
            }

           if (customer.CustPinCode.ToString().Length != 6)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Pincode must have 6 Digits only .");
            }
            if (customer.CustContactNo.ToString().Length != 10)
            {
                validCust = false;
                sb.Append(Environment.NewLine + " Phone number must have 10 digits only");
            }

            string email = customer.CustEmailId.ToString();
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            System.Text.RegularExpressions.Match match = regex.Match(email);

            if (match.Success)
            {
                validCust = true;
            }
            else
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Customer Id is not valid");
            }

           

            if (validCust == false)
            {
                throw new CustomerExceptions(sb.ToString());
            }

            return validCust;

        }

        // Function to add Customer
        public static bool AddCustomerBL(Customer customer)
        {
            bool custAdded = false;

            try
            {
                if (ValidateCust(customer))
                {
                    CustomerDAL custDAL = new CustomerDAL();
                    custAdded = custDAL.InsertDAL(customer);
                }
            }
            catch (CustomerExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return custAdded;
        }


        //BL Method to populate the grid

        public IEnumerable<Customer> SelectAllBL()
        {
            IEnumerable<Customer> customer = null;
            try
            {

                CustomerDAL customerDAL = new CustomerDAL();
                customer = customerDAL.SelectAllDAL();

            }
            catch (CustomerExceptions cs)
            {
                throw cs;
            }
            catch (Exception)
            {
                throw;
            }

            return customer;

        }



    }

}