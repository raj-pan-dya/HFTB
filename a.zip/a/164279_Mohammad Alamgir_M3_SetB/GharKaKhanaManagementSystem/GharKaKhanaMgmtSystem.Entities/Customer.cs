﻿
// /<Summary>
/*********************************************************************
 * File                 : Customer.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the properties of Customer Class.
 * Version              : 1.0
 * Last Modified Date   : 14-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GharKaKhanaMgmtSystem.Entities
{
    public class Customer
    {

        // Property Definition 

        private int _id;
        public int CustId
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }
        private string _custName;
        public string CustName
        {
            get
            {
                return _custName;
            }
            set
            {
                _custName = value;
            }
        }


        private string _custAddress;
        public string CustAddress
        {
            get
            {
                return _custAddress;
            }
            set
            {
                _custAddress = value;
            }
        }


        private string _custLandMark;
        public string CustLandMark
        {
            get
            {
                return _custLandMark;
            }
            set
            {
                _custLandMark = value;
            }
        }
        

        private string _custCity;
        public string CustCity
        {
            get
            {
                return _custCity;
            }
            set
            {
                _custCity = value;
            }
        }


        private int _custPinCode;
        public int CustPinCode
        {
            get
            {
                return _custPinCode;
            }
            set
            {
                _custPinCode = value;
            }
        }

        private string _custContactNo;
        public string CustContactNo
        {
            get
            {
                return _custContactNo;
            }
            set
            {
                _custContactNo = value;
            }
        }

        private string _custEmailId;
        public string CustEmailId
        {
            get
            {
                return _custEmailId;
            }
            set
            {
                _custEmailId = value;
            }
        }

    }
}
