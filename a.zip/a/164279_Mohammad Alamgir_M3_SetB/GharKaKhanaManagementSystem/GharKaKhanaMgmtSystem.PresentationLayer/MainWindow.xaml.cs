﻿
// /<Summary>
/*********************************************************************
 * File                 : MainWindow.xaml.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to for GUI Design.
 * Version              : 1.0
 * Last Modified Date   : 14-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GharKaKhanaMgmtSystem.Entities;
using GharKaKhanaMgmtSystem.Exceptions;
using GharKaKhanaMgmtSystem.DataAccessLayer;
using GharKaKhanaMgmtSystem.BusinessLayer;

namespace GharKaKhanaMgmtSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CustomerBL cBl = new CustomerBL();
        Customer customer = null;
        public MainWindow()
        {
            InitializeComponent();
          
        }

        // Validate Customer
         
        private bool IsValidCustomer()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;
            if (txtCustomerName.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Customer Name cannot be Blank");
            }
            if (txtCustomerAddress.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Address cannot be Blank");
            }
            if (txtCustomerLandmark.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Landmark cannot be Blank");
            }
            if (txtPincode.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Pincode cannot be Blank");
            }

            if (txtContactNo.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Contact No cannot be Blank");
            }
            
            if (txtCity.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + " City cannot be Blank");
            }
            if (txtEmail.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Email cannot be Blank");
            }
            if (isValid == false)
            {
                throw new CustomerExceptions(sb.ToString());
            }

            return isValid;
        }

        // Function to Populate UI

        public void PopulateUI()
        {
            try
            {
                IEnumerable<Customer> cust = cBl.SelectAllBL();

               
                txtCustomerGrid.ItemsSource = cust;
               

            }

            catch (CustomerExceptions ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

         // Function to add Customer

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValidCustomer())
                {
                    customer = new Customer();
                    customer.CustName = txtCustomerName.Text;
                    customer.CustAddress = txtCustomerAddress.Text;
                    customer.CustLandMark = txtCustomerLandmark.Text;
                    customer.CustCity = txtCity.Text;
                    customer.CustEmailId = txtEmail.Text;
                    customer.CustPinCode = Convert.ToInt32(txtPincode.Text);
                    customer.CustContactNo = txtContactNo.Text;

                    status = CustomerBL.AddCustomerBL(customer);
                    PopulateUI();

                }
                if (status == true)
                    MessageBox.Show("Customer Added Successfully!!!!!");

            }
            catch (CustomerExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Function to Clear All Customers

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                txtCustomerName.Text = string.Empty;
                txtCustomerAddress.Text = string.Empty;
                txtCustomerLandmark.Text = string.Empty;
                txtCity.Text = string.Empty;
                txtPincode.Text = string.Empty;
                txtEmail.Text = string.Empty;
                txtContactNo.Text = string.Empty;

                PopulateUI();

            }
            catch (CustomerExceptions ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }


        }

    }

}


