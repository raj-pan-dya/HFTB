﻿
// /<Summary>
/*********************************************************************
 * File                 : CustomerExceptions.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the Exceptions.
 * Version              : 1.0
 * Last Modified Date   : 14-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace GharKaKhanaMgmtSystem.Exceptions
{
    public class CustomerExceptions : ApplicationException
    {
        public CustomerExceptions()
        {
        }

        public CustomerExceptions(string message) : base(message)
        {
        }

        public CustomerExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected CustomerExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
