﻿
// /<Summary>
/*********************************************************************
 * File                 : CustomerDAL.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to define the Customer functions of Data Access.
 * Version              : 1.0
 * Last Modified Date   : 14-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
///</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Threading.Tasks;
using GharKaKhanaMgmtSystem.Entities;
using GharKaKhanaMgmtSystem.Exceptions;

namespace GharKaKhanaMgmtSystem.DataAccessLayer
{
    public class CustomerDAL
    {
        // Decleration Of SqlConnection Object Reference 

        SqlConnection cn = null;

        // Decleration Of Sql Command Object Reference

        SqlCommand cmd = null;

       // Decleration Of Sql Command Object Reference

        SqlDataReader dr = null;

        // Constructor for Connection

        public CustomerDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);

        }

        // Function to insert new Products.

        public bool InsertDAL(Customer customer)
        {
            bool isInserted = false;

            try
            {
                //cmd = new SqlCommand("INSERT INTO [Alamgir].[Customer] 

                //VALUES(@custName, @custAddress, @custLandMrak, @custCity, @custPin, @custContact, @custEmailId);", cn);

                cmd = new SqlCommand("[Alamgir].[USP_AddCustomer]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@custName", customer.CustName);
                cmd.Parameters.AddWithValue("@custAddress", customer.CustAddress);
                cmd.Parameters.AddWithValue("@custLandMark", customer.CustLandMark);
                cmd.Parameters.AddWithValue("@custCity", customer.CustCity);
                cmd.Parameters.AddWithValue("@custPin", customer.CustPinCode);
                cmd.Parameters.AddWithValue("@custContact", customer.CustContactNo);
                cmd.Parameters.AddWithValue("@custEmailId", customer.CustEmailId);
                
                cn.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }

            catch (CustomerExceptions udObj)
            {
                throw udObj;
            }

            catch (Exception ObjEx)
            {
                throw ObjEx;
            }



            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }

            return isInserted;

        }

        // Function to Select All Products

        public IEnumerable<Customer> SelectAllDAL()
        {
            List<Customer> customers = new List<Customer>();
            try
            {
                cmd = new SqlCommand("select * from [Alamgir].[Customer]", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Customer c = new Customer();
                        c.CustId = Convert.ToInt32(dr[0]);
                        c.CustName = dr[1].ToString();
                        c.CustAddress = dr[2].ToString();
                        c.CustLandMark = dr[3].ToString();
                        c.CustCity = dr[4].ToString();
                        c.CustPinCode = Convert.ToInt32(dr[5]);
                        c.CustContactNo = dr[6].ToString();
                        c.CustEmailId = dr[7].ToString();
                        
                        customers.Add(c);
                    }
                }
                dr.Close();
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return customers;
        }




    }
}
