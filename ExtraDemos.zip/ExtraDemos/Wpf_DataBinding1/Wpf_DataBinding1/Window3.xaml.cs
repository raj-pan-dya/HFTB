﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding1
{
    /// <summary>
    /// Interaction logic for Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        List<Employee> emps = null;

        public Window3()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            emps = new List<Employee> { 
                new Employee { EmpId = 101, EmpName = "Dinesh", Salary = 23000, DOJ = DateTime.Now.AddYears(-20) },
                new Employee { EmpId = 102, EmpName = "Rajashri", Salary = 28900, DOJ = DateTime.Now.AddYears(-21) },
                new Employee { EmpId = 103, EmpName = "Manisha", Salary = 34500, DOJ = DateTime.Now.AddYears(-23) },
                new Employee { EmpId = 104, EmpName = "Lalit", Salary = 45000, DOJ = DateTime.Now.AddYears(-25) },
                new Employee { EmpId = 105, EmpName = "Kailash", Salary = 54000, DOJ = DateTime.Now.AddYears(-31) },
            };
            this.DataContext = emps;
        }

        private void lbEmpNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Employee emp = (Employee) lbEmpNames.SelectedItem;
            MessageBox.Show( emp.EmpId+", "+emp.EmpName+", "+emp.DOJ+", "+emp.Salary);
        }     
    }
}
