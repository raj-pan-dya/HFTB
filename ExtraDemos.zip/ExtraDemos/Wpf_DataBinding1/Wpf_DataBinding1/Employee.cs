﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wpf_DataBinding1
{
    class Employee 
    {       
        private int empId;
        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }

        private string empName;       
        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }

        public DateTime DOJ { get; set; }
        public double Salary { get; set; }        
    }
}
