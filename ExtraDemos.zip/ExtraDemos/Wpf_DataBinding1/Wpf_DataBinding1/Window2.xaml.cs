﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_DataBinding1
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        Employee emp = null;

        public Window2()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            emp = new Employee();
            emp.EmpId = 101;
            emp.EmpName = "Rutuja";
            this.DataContext = emp;
        }

        private void btnChangeObject_Click(object sender, RoutedEventArgs e)
        {
            emp.EmpId = 102;
            emp.EmpName = "Rajesh";
        }

        private void btnShowObject_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(emp.EmpId+", "+emp.EmpName);
        }

       
    }
}
