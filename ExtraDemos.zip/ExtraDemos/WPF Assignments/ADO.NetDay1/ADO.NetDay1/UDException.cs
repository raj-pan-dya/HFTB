﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace ADO.NetDay1
{
    [Serializable]
    internal class UDException : Exception
    {
        public UDException()
        {
        }

        public UDException(string message) : base(message)
        {
        }

        public UDException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UDException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
