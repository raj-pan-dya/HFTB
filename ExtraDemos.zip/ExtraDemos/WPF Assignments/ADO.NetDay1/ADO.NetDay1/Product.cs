﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.NetDay1
{
    public class Product
    {
        public int Id { get; set; }
        public string ProdName { get; set; }
        public decimal Price { get; set; }
        public DateTime ExpDate { get; set; }
    }
}
