﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization;

namespace ADO.NetDay1
{
    public class ProductDAL 
    {

        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);

        }



        public void Insert(Product product)
        {
            try
            {
                // cmd = new SqlCommand(" insert into Alamgir.Product values (@pName, @price, @expDate)", cn);

                cmd = new SqlCommand("[Alamgir].[USP_InsertProduct]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@expDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
            }

            catch (UDException udObj)
            {
                throw udObj;
            }

            catch (Exception ObjEx)
            {
                throw ObjEx;
            }



            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }

        }

        public void Update(Product product)
        {
            try
            {
                //cmd = new SqlCommand("update [Alamgir].[Product] set ProdName=@pName, Price=@price, ExpDate=@eDate where Id=@id", cn);
                cmd = new SqlCommand("[Alamgir].[USP_UpdateProduct]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@expDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (UDException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public void Delete(Product product)
        {
            try
            {
                //cmd = new SqlCommand("update [Alamgir].[Product] set ProdName=@pName, Price=@price, ExpDate=@eDate where Id=@id", cn);

                cmd = new SqlCommand("[Alamgir].[USP_DeleteProduct]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
               
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (UDException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
        public IEnumerable<Product> SelectAll()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand("select * from [Alamgir].[Product]", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return products;
        }

    }

}
