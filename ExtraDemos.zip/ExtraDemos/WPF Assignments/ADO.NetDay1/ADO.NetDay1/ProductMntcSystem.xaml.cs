﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ADO.NetDay1
{
    /// <summary>
    /// Interaction logic for ProductMntcSystem.xaml
    /// </summary>
    public partial class ProductMntcSystem : Window 
    {
        ProductDAL pdal = new ProductDAL();

        public void PopulateUI()
        {
            IEnumerable<Product> prods = pdal.SelectAll();
            txtProductGrid.ItemsSource = prods;
            ComboName.ItemsSource = prods;
            ComboName.DisplayMemberPath = "ProdName";
        }

        public ProductMntcSystem()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        public bool IsInputValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (ComboName.Text == null | ComboName.Text == string.Empty | ComboName.Text.Length < 1)
            {
                sb.Append("\nProduct Name is Mandatory!");
                isValid = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty | txtPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (txtDate.Text == null | txtDate.Text == string.Empty | txtDate.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new UDException(sb.ToString());
            }

            return isValid;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (IsInputValid())
                {
                    Product p = new Product();
                    {
                        p.ProdName = ComboName.Text;
                        p.Price = Convert.ToDecimal(txtPrice.Text);
                        p.ExpDate = Convert.ToDateTime(txtDate.Text);
                    }
                    pdal.Insert(p);
                    MessageBox.Show(" Product inserted Successfully..!!");

                    PopulateUI();
                }
            }
            catch (UDException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
          
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
              Product p = (Product)ComboName.SelectedItem;
                    p.ProdName = ComboName.Text.ToString();
                    p.Price = Convert.ToDecimal(txtPrice.Text);
                    p.ExpDate = Convert.ToDateTime(txtDate.Text);
                    
                    pdal.Update(p);
                    MessageBox.Show(" Product Updated Successfully..!!");

                    PopulateUI();
                
            }
            catch (UDException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Product p = (Product)ComboName.SelectedItem;
                pdal.Delete(p);
                MessageBox.Show(" Product Deleted Successfully..!!");

                PopulateUI();


            }
            catch (UDException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        //private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        //{

        //}

        private void cmbProdName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            Product p = (Product)ComboName.SelectedItem;

            MessageBox.Show(p.Id.ToString());
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{

        //}
    }
}
