﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Lab3
{
    public partial class Registration_Form : Form
    {
        public Registration_Form()
        {
            InitializeComponent();
        }

        private void lblDateOfBirth(object sender, EventArgs e)
        {

        }

        private void imgcal_Click(object sender, EventArgs e)
        {
            CalenderDialog cal = new CalenderDialog();
            cal.StartPosition = FormStartPosition.CenterScreen;
            if (cal.ShowDialog() == DialogResult.OK)
            txtdateofbirth.Text = cal.DateSelection.SelectionStart.ToString("dd- MMM - yyyy");
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            MessageBox.Show("  Welcome  " + txtname.Text + " !!!!!"+" \n\nYour Date Of Birth is: " 
                + txtdateofbirth.Text  );
        }
    }
}
