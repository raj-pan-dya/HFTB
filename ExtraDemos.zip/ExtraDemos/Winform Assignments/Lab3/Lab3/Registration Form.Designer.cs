﻿namespace Lab3
{
    partial class Registration_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration_Form));
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lbldateofbirth = new System.Windows.Forms.Label();
            this.txtdateofbirth = new System.Windows.Forms.TextBox();
            this.btnregister = new System.Windows.Forms.Button();
            this.imgcal = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).BeginInit();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.Location = new System.Drawing.Point(35, 27);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(61, 23);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Name";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(115, 27);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 20);
            this.txtname.TabIndex = 1;
            // 
            // lbldateofbirth
            // 
            this.lbldateofbirth.Location = new System.Drawing.Point(26, 73);
            this.lbldateofbirth.Name = "lbldateofbirth";
            this.lbldateofbirth.Size = new System.Drawing.Size(70, 23);
            this.lbldateofbirth.TabIndex = 2;
            this.lbldateofbirth.Text = "Date Of Birth";
            this.lbldateofbirth.Click += new System.EventHandler(this.lblDateOfBirth);
            // 
            // txtdateofbirth
            // 
            this.txtdateofbirth.Location = new System.Drawing.Point(115, 70);
            this.txtdateofbirth.Name = "txtdateofbirth";
            this.txtdateofbirth.Size = new System.Drawing.Size(100, 20);
            this.txtdateofbirth.TabIndex = 3;
            // 
            // btnregister
            // 
            this.btnregister.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnregister.Location = new System.Drawing.Point(89, 113);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(101, 27);
            this.btnregister.TabIndex = 4;
            this.btnregister.Text = "Register";
            this.btnregister.UseVisualStyleBackColor = false;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // imgcal
            // 
            this.imgcal.Image = ((System.Drawing.Image)(resources.GetObject("imgcal.Image")));
            this.imgcal.Location = new System.Drawing.Point(232, 70);
            this.imgcal.Name = "imgcal";
            this.imgcal.Size = new System.Drawing.Size(22, 20);
            this.imgcal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgcal.TabIndex = 5;
            this.imgcal.TabStop = false;
            this.imgcal.Click += new System.EventHandler(this.imgcal_Click);
            // 
            // Registration_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(306, 184);
            this.Controls.Add(this.imgcal);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.txtdateofbirth);
            this.Controls.Add(this.lbldateofbirth);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblname);
            this.Name = "Registration_Form";
            this.Text = "Registration_Form";
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lbldateofbirth;
        private System.Windows.Forms.TextBox txtdateofbirth;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.PictureBox imgcal;
    }
}