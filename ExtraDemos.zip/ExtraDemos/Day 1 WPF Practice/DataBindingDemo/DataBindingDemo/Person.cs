﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingDemo
{
    class Person
    {
        public int Id { get; set; }

        public string FullName { get; set; }

        public DateTime DOB { get; set; }

        public string MobileNo { get; set; }

        public string State { get; set; }


        public static IEnumerable<Person> GetPeople()
        {
            return new List<Person>
        {
            new Person{ Id = 101 , FullName = "Alamgir Mohammad", DOB = DateTime.Now.AddYears(-21), MobileNo = "7741904895", State = "Bihar"},
            new Person{ Id = 202 , FullName = "Rahul Gulia" ,DOB = DateTime.Now.AddYears(-25), MobileNo = "8641114895", State = "Haryana"},
            new Person{ Id = 303 , FullName = "Ratnesh Agrahari" ,DOB = DateTime.Now.AddYears(-20), MobileNo = "7841904895", State = "Up"},
            new Person{ Id = 402 , FullName = "Rakesh Dahiya" ,DOB = DateTime.Now.AddYears(-28), MobileNo = "9931904895", State = "Delhi"}
        };

        }

    }
}
