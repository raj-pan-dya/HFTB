﻿using System;
using System.Runtime.Serialization;

namespace PMS_AdoConArch_Demo
{
    [Serializable]
    internal class UDException : Exception
    {
        public UDException()
        {
        }

        public UDException(string message) : base(message)
        {
        }

        public UDException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UDException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}