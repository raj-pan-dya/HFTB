﻿/*********************************************************************
* File                 : StringOperations.cs
* Author Name          : Alamgir Mohammad
* Desc                 : Program to call a searchPosition using Reflection.
* Version              : 1.0
* Last Modified Date   : 05-Dec-2018
* Change Description   : Description about the changes implemented
*********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StringOperations;
using System.Reflection;
using System.IO;


namespace OperationStringM2_2
{
    class Program
    {
        static void Main(string[] args)
        {
           // Assembly assembly = Assembly.GetExecutingAssembly();
            Type type = typeof(StringOperations.Clibrary.StringOperations);
           // Type t = assembly.GetType("StringOperations.Clibrary.StringOperations");
            MethodInfo methodInfo = type.GetMethod("SearchPosition", BindingFlags.Public | BindingFlags.Static);
            int result = (int)methodInfo.Invoke(null, new object[] { "alamgir", 'a' });
            Console.WriteLine("The Character found at : " + result);

            Console.ReadKey();
        }
    }
}
