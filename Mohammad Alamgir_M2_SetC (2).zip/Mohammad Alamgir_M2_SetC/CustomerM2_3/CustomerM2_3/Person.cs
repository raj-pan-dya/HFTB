﻿/*********************************************************************
 * File                 : Customer.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to inherit a class and over ride its method..
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerM2_3
{
    class Person
    {
        private int _Id;
        private string _name;
        private int _age;
        private string _dateOfBirth;

        //Properties Creation

        public int Id
        {
            get
            {
                return _Id;
            }

            set
            {
                _Id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }
        }

        public string DateOfBirth
        {
            get
            {
                return _dateOfBirth;
            }

            set
            {
                _dateOfBirth = value;
            }
        }
        
        //To Print Details

        public virtual void printDetails()
        {
            Console.WriteLine();
            Console.WriteLine("================= Details=====================");
            Console.WriteLine(" Person ID :"+ Id);
            Console.WriteLine(" Person Name :" + Name);
            Console.WriteLine(" Person Age :" + Age);
            Console.WriteLine(" Person Date Of Birth :" + DateOfBirth);
            Console.WriteLine("==============================================");
            Console.WriteLine();
        }

    }
}
