﻿//<Summary>
/*********************************************************************
 * File                 : DoctorBL.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to implement Doctor Management System
                          using layered Architecture.
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
//</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem.Exceptions;
using DoctorMgmtSystem.DataAccessLayer;

namespace DoctorMgmtSystem.BusinessLayer
{
    public class DoctorBL
    {
        // Function to validate a doctor

        private static bool validateDoctor(Doctor objDoctor)
        {
            StringBuilder objSB = new StringBuilder();
            bool validDoctor = true;

            if (objDoctor.DoctRegistraionNumber.ToString().Length < 7 )
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Required 7 digit Registration number. ");
            }

            if (objDoctor.DoctName == string.Empty)
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Employee Name required . ");
            }

            if (objDoctor.DoctAreaOfSpecialization == string.Empty)
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Area Of Specialization required . ");
            }

            if (objDoctor.DoctCity == string.Empty)
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Doctor City is Required required . ");
            }

            if (objDoctor.DoctClinicAddress == string.Empty)
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Doctor Address is Required required . ");
            }

            if (objDoctor.DoctClinincTimings == null)
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Time is Required required . ");
            }

            if (objDoctor.DoctContactNumber.ToString().Length < 10)
            {
                validDoctor = false;
                objSB.Append(

                    Environment.NewLine + " Required 10 digit Contact number. ");
            }


            if (validDoctor == false)
            {
                throw new DoctorMgmtSystemException(objSB.ToString());
            }

            return validDoctor;


        }

        // Logic to add a doctor in the list

        public static bool addDoctorBL(Doctor objDoctor)
        {
            bool doctorAdded = false;

            try
            {
                if (validateDoctor(objDoctor))
                {
                    DoctorDAL objDoctorDAL = new DoctorDAL();
                    doctorAdded = objDoctorDAL.addDoctorDAL(objDoctor);
                }
            }

            catch (DoctorMgmtSystemException objEmpMgmSystExp)
            {
                throw objEmpMgmSystExp;
            }

            catch (Exception objEx)
            {
                throw objEx;
            }

            return doctorAdded;
        }


        // Logic to search a doctor from list

        public static Doctor searchDoctorBL(int registration_id)
        {
            Doctor objDoctor = null;

            try
            {
                DoctorDAL objDoctorDAL = new DoctorDAL();
                objDoctor = objDoctorDAL.searchDoctorDAL(registration_id);
            }

            catch (DoctorMgmtSystemException objEmpMgmSystExp)
            {
                throw objEmpMgmSystExp;
            }

            catch (Exception objEx)
            {
                throw objEx;
            }

            return objDoctor;
        }


        //Logic to list all Doctors

        public static List<Doctor> getAllDoctorBL()
        {

            List<Doctor> objDoctorList;

            try
            {
                DoctorDAL objDoctorDAL = new DoctorDAL();
                objDoctorList = objDoctorDAL.getAllDoctorDAL();
            }

            catch (DoctorMgmtSystemException objEmpMgmSystExp)
            {
                throw objEmpMgmSystExp;
            }

            catch (Exception objEx)
            {
                throw objEx;
            }

            return objDoctorList;

        }
    }
}
