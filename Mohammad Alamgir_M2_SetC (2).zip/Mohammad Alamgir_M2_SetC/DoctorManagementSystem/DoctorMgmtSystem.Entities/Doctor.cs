﻿//<Summary>
/*********************************************************************
 * File                 : Doctor.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to implement Doctor Management System
                          using layered Architecture.
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
 //</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DoctorMgmtSystem.Entities
{

    [Serializable]

    public class Doctor
    {
        private int _doctRegistrationNumber;
        private string _doctName;
        private string _doctCity;
        private string _doctAreaOfSpecsn;
        private string _doctClinicAddress;
        private DateTime _doctClinicTimings;
        private string _doctContactNumber;

        //Propertie Creation

        public int DoctRegistraionNumber
        {
            get
            {
                return _doctRegistrationNumber;
            }

            set
            {
                _doctRegistrationNumber = value;
            }
        }

        public string DoctName
        {
            get
            {
                return _doctName;
            }

            set
            {
                _doctName = value;
            }
        }


        public string DoctCity
        {
            get
            {
                return _doctCity;
            }

            set
            {
                _doctCity = value;
            }
        }


        public string DoctAreaOfSpecialization
        {
            get
            {
                return _doctAreaOfSpecsn;
            }

            set
            {
                _doctAreaOfSpecsn = value;
            }
        }


        public string DoctClinicAddress
        {
            get
            {
                return _doctClinicAddress ;
            }

            set
            {
                _doctClinicAddress = value;
            }
        }


        public DateTime DoctClinincTimings
        {
            get
            {
                return _doctClinicTimings;
            }

            set
            {
                _doctClinicTimings = value;
            }
        }

        public string DoctContactNumber
        {
            get
            {
                return _doctContactNumber;
            }

            set
            {
                _doctContactNumber = value;
            }
        }


    }
}
