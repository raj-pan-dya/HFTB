﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstWpf_App
{
    /// <summary>
    /// Interaction logic for EmpRegistration.xaml
    /// </summary>
    public partial class EmpRegistration : Window
    {
        public EmpRegistration()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            string strData = string.Empty;
            strData += txtName.Text +"\n";
            strData += txtDOB.Text;
            strData += cmbItems.Text;
            foreach (ListBoxItem item in cmbItems.Items)
            {
                if (item.IsSelected)
                {
                    strData += item.Content;
                    break;
                }
            }

            MessageBox.Show(strData);
        }
    }
}
