﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BindingDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<string> list = null;
        

    public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new List<string> { "Maharashtra", "Bihar", "Madhya Pradesh" };
        }

        private void listStates_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listStates.SelectedIndex == 0)
            {
                list = new List<string> { "Pune", "Nagpur", "Mumbai", "Thane" };
                listCity.ItemsSource = list;
            }
            if (listStates.SelectedIndex == 1)
            {
                list = new List<string> { "Patna", "Motihari", "Raxaul", "Bettiah" };
                listCity.ItemsSource = list;

            }
            if (listStates.SelectedIndex == 2)
            {
                list = new List<string> { "Bhopal", "Seoni", "Jabal Pur", "Satna" };
                listCity.ItemsSource = list;
            }
           // return list;
        }

        //private void listCity_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    if (l2.SelectedValue.Equals("Pune") || l2.SelectedValue.Equals("Nagpur") || l2.SelectedValue.Equals("Thane") || l2.SelectedValue.Equals("Mumbai"))
        //    {
        //        l1.ItemsSource = new List<string> { "MH" };
        //    }
        //    if (l2.SelectedValue.Equals("Bhopal") || l2.SelectedValue.Equals("Jabalpur") || l2.SelectedValue.Equals("Seoni") || l2.SelectedValue.Equals("Indore"))
        //    {
        //        l1.ItemsSource = new List<string> { "MP" };
        //    }
        //    if (l2.SelectedValue.Equals("Gaya") || l2.SelectedValue.Equals("Patna") || l2.SelectedValue.Equals("Deoghar") || l2.SelectedValue.Equals("Motihari"))
        //    {
        //        l1.ItemsSource = new List<string> { "Bihar" };
        //    }
        //}
    }
}
